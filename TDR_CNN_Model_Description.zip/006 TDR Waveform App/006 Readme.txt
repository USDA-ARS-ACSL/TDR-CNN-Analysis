The TDR waveforms are in 
Timlin, D.J. and Pachepsky, Y.A.. 2002. Infiltration measurement using a vertical time-domain 706 reflectometry probe and a reflection simulation model. Soil Science. 167:1-8.

We follow the same way as in 005, i.e., using "TDR_Data_Interp_Framework.py" to run all the three modules, and all the H5 files should be copied here.

For simplicity, because there are only 6 data, we can use "APP_TDR.py" for demonstration.