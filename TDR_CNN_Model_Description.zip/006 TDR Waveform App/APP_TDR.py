# this is the code start with read the waveforms

import sys
import numpy as np
import pandas as pd
import tensorflow as tf
# import sklearn as skl

np.set_printoptions(threshold=sys.maxsize)

###############################################################################
# Prepare necessary dataset for TDR RPN training

WaveData_1sec=pd.read_csv('11.csv', header=None).astype(np.float32)
WaveData_1sec=WaveData_1sec.to_numpy(copy=True)
WaveData_1sec=(WaveData_1sec+1)/2.5
DataLength_1sec, WaveWidth_1sec=WaveData_1sec.shape
WaveData_1sec=WaveData_1sec.reshape((DataLength_1sec, WaveWidth_1sec))

WaveData_tf=[]

for kk in np.arange(DataLength_1sec):
    wf=tf.convert_to_tensor(WaveData_1sec[kk].reshape((WaveWidth_1sec,1)))
    WaveData_tf.append(wf)   
    
    
DataLength_tf=DataLength_1sec
WaveWidth_tf=WaveWidth_1sec
WaveData_tf=np.asarray(WaveData_tf)

del WaveData_1sec

# Finish prepare the dataset

###############################################################################
# preload the TDR_CNN model 
model_pretrain=tf.keras.models.load_model('myVGG1D_H5')
Layer_Conv_1_Kernel=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[0])
Layer_Conv_1_Bias=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[1])
Layer_Conv_2_Kernel=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[0])
Layer_Conv_2_Bias=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[1])
Layer_Conv_3_Kernel=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[0])
Layer_Conv_3_Bias=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[1])
Layer_Conv_4_Kernel=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[0])
Layer_Conv_4_Bias=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[1])

base_model=tf.keras.Sequential([
    tf.keras.layers.InputLayer(input_shape=(WaveWidth_tf,1)),
    tf.keras.layers.Conv1D(filters=4, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_1_Kernel, bias_initializer=Layer_Conv_1_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=8, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_2_Kernel, bias_initializer=Layer_Conv_2_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=16, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_3_Kernel, bias_initializer=Layer_Conv_3_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=32, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_4_Kernel, bias_initializer=Layer_Conv_4_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
])

for layer in base_model.layers:
    layer.trainable=False

# the waveform feature has dimension 40000(datapoint)*62/50(spatial point)*16/24/32(features)
WaveFeature_tf=base_model.predict(WaveData_tf)


###############################################################################
# prepare the box dataset 
import bbox_utils, train_utils

hyper_params=train_utils.get_hyper_params()
# We add 1 class for background
hyper_params["total_labels"]=3+1 

    
# create the anchor boxes    
anchors = bbox_utils.generate_anchors(hyper_params)    

feature_map_shape = hyper_params["feature_map_shape"]
anchor_count = hyper_params["anchor_count"]
total_pos_bboxes = hyper_params["total_pos_bboxes"]
total_neg_bboxes = hyper_params["total_neg_bboxes"]
variances = hyper_params["variances"]

###############################################################################

rpn_model=tf.keras.models.load_model('myRPN1D_H5',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})  
rpn_model_1st=tf.keras.models.load_model('myRPN1D_H5_1st',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})   
rpn_model_2nd=tf.keras.models.load_model('myRPN1D_H5_2nd',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})   

WaveRPN_tf=rpn_model.predict(WaveFeature_tf)
rpn_reg_tf, rpn_cls_tf=WaveRPN_tf

WaveRPN_tf_1st=rpn_model_1st.predict(WaveFeature_tf)
rpn_reg_tf_1st, rpn_cls_tf_1st=WaveRPN_tf_1st

WaveRPN_tf_2nd=rpn_model_2nd.predict(WaveFeature_tf)
rpn_reg_tf_2nd, rpn_cls_tf_2nd=WaveRPN_tf_2nd

import wave_utils
###############################################################################
# first detect the 1st reflection position

#rpn_bbox_1st = wave_utils.get_proposal_bboxes_1st(DataLength_tf, rpn_reg_tf_1st, rpn_cls_tf_1st, anchors)
#rflx_res_1st = wave_utils.get_rflx_position_1st(DataLength_tf, rpn_bbox_1st, WaveData_tf)

###############################################################################
# second detect the 2nd reflection position

#rpn_bbox_2nd = wave_utils.get_proposal_bboxes_2nd(DataLength_tf, rpn_reg_tf_2nd, rpn_cls_tf_2nd, anchors)
#rflx_res_2nd = wave_utils.get_rflx_position_2nd(DataLength_tf, rpn_bbox_2nd, WaveData_tf)

##############################################################################
# third detect internal reflection positions
# using the first and second refection position as the pre-knowledge

rpn_bbox = wave_utils.get_proposal_bboxes(DataLength_tf, rpn_reg_tf, rpn_cls_tf, anchors)
rflx_res, rflx_num = wave_utils.get_rflx_position(DataLength_tf, rpn_bbox, WaveData_tf)



###############################################################################
## determine the relative permittivity

Feeding_range=50.0
Er_small_thre=5.0
Er_res=[]
model_reg=tf.keras.models.load_model('myREGH5.h5')

for kk in np.arange(DataLength_tf):
        
    rflx_num_each=rflx_num[kk]
    rflx_res_each=rflx_res[kk]
    Wave_each=WaveData_tf[kk]
    Wave_Feeding=[]
    
    # for each waveform, transform each segment into the standard format, 50*1 length
    for tt in np.arange(1,rflx_num_each,dtype=np.int32):
        
        pt_1=np.ceil(rflx_res_each[tt-1])
        pt_2=np.ceil(rflx_res_each[tt])
        pt_1_int=pt_1.astype(np.int32)
        pt_2_int=pt_2.astype(np.int32)
        
        Wave_seg=np.array(Wave_each[pt_1_int:pt_2_int,]).reshape((-1))
        x_Wave_seg=(np.arange(pt_1,pt_2).astype(np.float32)-pt_1)/(pt_2-pt_1)*Feeding_range
        x_interp=np.arange(0,Feeding_range).astype(np.float32)
        Wave_interp=np.interp(x_interp,x_Wave_seg,Wave_seg)
        
        Wave_Feeding.append(Wave_interp)
        
    # for each waveform, make prediction with the regression network   
    Wave_Feeding=np.array(Wave_Feeding)
    Wave_Feeding=np.expand_dims(Wave_Feeding,2)
    Er_res_each=model_reg.predict(Wave_Feeding)
    
    # check if the Er values is smaller than 5, then remove that section since they are subjected to multiple reflection
    
    remove=0
#    for tt in np.arange(rflx_num_each-1,0,-1,dtype=np.int32):
        
#        if Er_res_each[tt-1]<0:
            
#           remove=remove-1
           
    
    if remove<0:
        Er_res_each=Er_res_each[:remove]
        rflx_res[kk]=rflx_res[kk][:remove]
        rflx_num[kk]=rflx_num_each+remove
    
    Er_res_each.reshape((-1))
    Er_res.append(Er_res_each)
        