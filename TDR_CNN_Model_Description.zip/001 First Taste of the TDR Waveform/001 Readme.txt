Two notebooks are presented
1. FDM_Pure_Water.ipynb: The TDR waveform simulated within pure water
2. FDM_Three_Section.ipynb: The TDR waveform simulated with three connected media, so two internal reflection positions can be observed.