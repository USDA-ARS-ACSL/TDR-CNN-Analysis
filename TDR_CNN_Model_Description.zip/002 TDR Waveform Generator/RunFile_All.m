run('WaveForm_1sec_Generator.m')
run('WaveForm_2sec_Generator.m')
run('WaveForm_3sec_Generator.m')
run('WaveForm_4sec_Generator.m')