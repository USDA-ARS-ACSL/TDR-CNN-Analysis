clear all
close all
rand('seed',160);

% the length of TDR sensor portions, cable + connection + probe
CableLength=0.50;
SolderLength=0.075;
ProbeLength=0.50;

% some physical constant
LightSpeed=3e08;                   % unit m/s
TimeMeasIntv=3.335640951981520e-11;     % uint s
DataLength=251;

% cable
L_Cable=3.5714e-07;
C_Cable=6.3492e-11;
R_Cable=0;
G_Cable=0;

% connection
L_Connc=1.5714e-07;
C_Connc=6.3492e-11;
R_Connc=0;
G_Connc=0;

% probe
L_Probe=2.0e-07;
C_Probe_Ori=7.5e-10;
R_Probe=0;
G_Probe=0;

% Source point
InputVoltage=1000/1000;            % unit V
InputRasingTime=3e-10;              % unit s
CableImped=75;                     % unit ohm
R_Source=75;                       % unit ohm
beta=1/(InputRasingTime);
Vin=CableImped/(R_Source+CableImped)*InputVoltage;

% define the input voltage and its derivative
Vs=@(t) Vin*(1-exp(-beta*t));
dVsdt=@(t) Vin*beta*exp(-beta*t);

% Loading point
R_Loading=2000;

Xdomain=CableLength+SolderLength+ProbeLength;
dx=0.002;
NX=ceil(Xdomain/dx);
XPlot=(0:NX).*dx;
dx=Xdomain/NX;
dt=dx/LightSpeed;
TotalTimeStep=3e3;

No_Cable=floor(CableLength/dx)+1;
No_Connc=floor((CableLength+SolderLength)/dx)+1-No_Cable;
No_Probe=NX-No_Cable-No_Connc;

% Now we made several simulations on the reflection position
NSimu=10000;
RandFactor=rand(10*NSimu,4);
for kk=1:10*NSimu
    if (abs(RandFactor(kk,1)-RandFactor(kk,2))<0.1) || (abs(RandFactor(kk,2)-RandFactor(kk,3))<0.1) || (abs(RandFactor(kk,3)-RandFactor(kk,4))<0.1)
        RandFactor(kk,:)=[-1,-1,-1,-1];
    end
end
RandFactor(RandFactor(:,1)==-1,:)=[];
RandFactor=RandFactor(1:NSimu,:);
NWavePoint=1000;
NNd=5;
TimeRflxNNd=zeros(NSimu,NNd);
WaveFormData=zeros(NSimu,NWavePoint);
WaveFormCatg=4.*ones(NSimu,1);

C_Probe_Res=(0.8750.*RandFactor+0.125).*C_Probe_Ori;
C_0=8.854187817e-12*pi/acosh(10);
Er_Res=C_Probe_Res./C_0;

xlswrite('4sec_Er.xlsx',Er_Res);

for n_simu=1:NSimu
    
    C_Probe_1=C_Probe_Ori.*(0.875.*RandFactor(n_simu,1)+0.125);
    C_Probe_2=C_Probe_Ori.*(0.875.*RandFactor(n_simu,2)+0.125);
    C_Probe_3=C_Probe_Ori.*(0.875.*RandFactor(n_simu,3)+0.125);
    C_Probe_4=C_Probe_Ori.*(0.875.*RandFactor(n_simu,4)+0.125);

    L=[L_Cable.*ones(No_Cable,1);L_Connc.*ones(No_Connc,1);L_Probe*ones(No_Probe+1,1)];
    C=[C_Cable.*ones(No_Cable,1);C_Connc.*ones(No_Connc,1);...
        C_Probe_1*ones(round(No_Probe/4),1);...
        C_Probe_2*ones(round(No_Probe/4),1);...
        C_Probe_3*ones(round(No_Probe/4),1);...
        C_Probe_4*ones(No_Probe+1-3*round(No_Probe/4),1)];
    R=[R_Cable.*ones(No_Cable,1);R_Connc.*ones(No_Connc,1);R_Probe*ones(No_Probe+1,1)];
    G=[G_Cable.*ones(No_Cable,1);G_Connc.*ones(No_Connc,1);G_Probe*ones(No_Probe+1,1)];

    IndexNNd=zeros(NNd,1);
    TimeIndexNNd=zeros(NNd,1);
    IndexNNd(1,1)=No_Cable+No_Connc+1;
    IndexNNd(2,1)=No_Cable+No_Connc+round(No_Probe/4)+1;
    IndexNNd(3,1)=No_Cable+No_Connc+2*round(No_Probe/4)+1;
    IndexNNd(4,1)=No_Cable+No_Connc+3*round(No_Probe/4)+1;
    IndexNNd(5,1)=No_Cable+No_Connc+No_Probe+1;

    % -------------- directly solve the equation system ---------------------

    Rs=R_Source;
    Rl=R_Loading;

    Vprev_1=zeros(NX+1,1);
    Vprev_2=zeros(NX+1,1);
    Vcurr=zeros(NX+1,1);
    Coef_A=zeros(NX+1,3);
    Coef_B=zeros(NX+1,1);
    
    WaveFormSimu=zeros(1,TotalTimeStep);

    % the differential equation
    for kk=2:NX
         Coef_A(kk,1)=-0.25*dt^2/dx^2/(L(kk)*C(kk));
         Coef_A(kk,2)=1+0.5*dt^2/dx^2/(L(kk)*C(kk));
         Coef_A(kk,3)=-0.25*dt^2/dx^2/(L(kk)*C(kk));
    end
    Coef_A(1,2)=1+dt*Rs/L(1)/dx;
    Coef_A(1,3)=-dt*Rs/L(1)/dx;
    Coef_A(NX+1,1)=-dt*Rl/L(NX+1)/dx;
    Coef_A(NX+1,2)=1+dt*Rl/L(NX+1)/dx;

    for T=1:TotalTimeStep

        Vprev_2=Vprev_1;
        Vprev_1=Vcurr;

        for kk=2:NX
            Coef_B(kk,1)=2*Vprev_1(kk)-Vprev_2(kk)+dt^2/dx^2/(L(kk)*C(kk))*...
                (0.5*(Vprev_1(kk+1)+Vprev_1(kk-1)-2*Vprev_1(kk))+...
                0.25*(Vprev_2(kk+1)+Vprev_2(kk-1)-2*Vprev_2(kk)));
        end
        Coef_B(1,1)=Vprev_1(1)+dt*dVsdt(T*dt-dt);
        Coef_B(NX+1,1)=Vprev_1(NX+1);

        Coef_AA=Coef_A;
        Coef_BB=Coef_B;

        % Thomas linear solver    
        for kk=2:NX+1
            ll=Coef_AA(kk,1)/Coef_AA(kk-1,2);
            Coef_AA(kk,2)=Coef_AA(kk,2)-Coef_AA(kk-1,3)*ll;
            Coef_BB(kk,1)=Coef_BB(kk,1)-Coef_BB(kk-1,1)*ll;
        end
        Vcurr(NX+1)=Coef_BB(NX+1,1)/Coef_AA(NX+1,2);
        for kk=NX:-1:1
            Vcurr(kk)=(Coef_BB(kk,1)-Vcurr(kk+1)*Coef_AA(kk,3))/Coef_AA(kk,2);
        end

        for kk=1:NNd
            if TimeIndexNNd(kk,1)==0
                if abs(Vcurr(IndexNNd(kk,1)))>=0.001
                    TimeIndexNNd(kk,1)=T;
                end
            end
        end

        WaveFormSimu(T)=Vcurr(1);
    end
    %WaveFormSimu=log10(WaveFormSimu);
%    Time=(1:T).*dt;
    WaveFormSimu=(WaveFormSimu-0.5*Vin)./(0.5*Vin);
    plot(WaveFormSimu)
%    Time=[0,Time];
    WaveFormSimu=[-1,WaveFormSimu];
    
    WaveFormData(n_simu,:)=WaveFormSimu(1:3:T);
    TimeRflxNNd(n_simu,:)=2.*TimeIndexNNd./3;
end

xlswrite('4sec_WaveForm.xlsx',WaveFormData);
xlswrite('4sec_Reflx.xlsx',TimeRflxNNd);
xlswrite('4sec_WaveFormCatg.xlsx',WaveFormCatg);