You will need to generate the simulated TDR waveforms (the datasets are too large to be uploaded)
1. Run "RunFile_All.m" to complete the wave generation procedure
2. "WaveForm_1sec_Generator.m" means the waveforms generated in this file will have one segment, no internal reflection position
3. "WaveForm_2sec_Generator.m" means the waveforms generated in this file will have two segments, with one internal reflection position between the two segments
4. Similar to "WaveForm_3sec_Generator.m" and "WaveForm_4sec_Generator.m"
5. The results include the generate waveforms, the turn reflection positions, the ture Er and the waveform_catg (i.e., 1-no internal reflection positon, 2-one internal reflection position, 3-two internal reflection positions, and 4-three internal reflection position).
