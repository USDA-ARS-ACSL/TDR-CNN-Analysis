# -*- coding: utf-8 -*-
"""
Created on Thu Jul  7 19:27:22 2022

@author: Zhuangji.Wang
"""

import tensorflow as tf
import numpy as np


def get_proposal_bboxes(DataLength_tf, rpn_reg_tf, rpn_cls_tf, anchors):
    
    nms_rflx_no=10
    
    proposal_boxes=[]
    
    for kk in np.arange(DataLength_tf):
                
        cls_score=rpn_cls_tf[kk]
        nms_reg=rpn_reg_tf[kk]
        
        cls_order_index=cls_score.ravel().argsort()
        cls_order_index=np.flip(cls_order_index)[0:nms_rflx_no]
        cls_order_index.sort()

        cls_score=cls_score[cls_order_index]
        cls_score=cls_score.squeeze()
        
        cls_order_index=tf.constant(cls_order_index, dtype=tf.int32)
        nms_anc_slice = tf.gather(anchors, cls_order_index)
        
        nms_anc_width=nms_anc_slice[...,1]-nms_anc_slice[...,0]
        nms_anc_ctr_x=nms_anc_slice[...,0]+0.5*nms_anc_width
        
        nms_bbox_width=tf.exp(nms_reg[cls_order_index, 1]) * nms_anc_width
        nms_bbox_ctr_x = (nms_reg[cls_order_index, 0] * nms_anc_width) + nms_anc_ctr_x
        
        x1 = nms_bbox_ctr_x - (0.5 * nms_bbox_width)
        x2 = x1 + nms_bbox_width
        
        result_index=0
        ctr_x_prev=0
        cls_score_prev=0
        
        nms_bbox=[]
        
        for tt in np.arange(nms_rflx_no):
    
            if cls_score[tt] > 0.4:
                
                if result_index==0:
                    
                    nms_bbox.append(np.array((x1[tt],x2[tt])).astype(np.float32))
                    result_index=result_index+1
                    ctr_x_prev=(x1[tt]+x2[tt])/2
                    cls_score_prev=cls_score[tt]
                
                else:
                    
                    if nms_bbox_ctr_x[tt]-ctr_x_prev > 40:
                        
                        nms_bbox.append(np.array((x1[tt],x2[tt])).astype(np.float32))
                        result_index=result_index+1
                        ctr_x_prev=(x1[tt]+x2[tt])/2
                        cls_score_prev=cls_score[tt]
                        
                    else:
                        
                        if cls_score[tt] >= (cls_score_prev+0.1):
                            
                            nms_bbox[result_index-1]=np.array((x1[tt],x2[tt])).astype(np.float32)
                            ctr_x_prev=(x1[tt]+x2[tt])/2
                            cls_score_prev=cls_score[tt]
                            
                        elif cls_score[tt] <= (cls_score_prev-0.1):
                            
                            pass
                            
                        else: 
                            
                            x1_expan=min(nms_bbox[result_index-1][0], x1[tt])
                            x2_expan=max(nms_bbox[result_index-1][1], x2[tt])
                            nms_bbox[result_index-1]=np.array((x1_expan,x2_expan)).astype(np.float32)
                            
                            ctr_x_prev=(x1_expan+x2_expan)/2
                            ctr_x_prev=max(ctr_x_prev,cls_score[tt])
                            
                            
                nms_bbox[result_index-1][0]=np.floor(nms_bbox[result_index-1][0])
                nms_bbox[result_index-1][1]=np.ceil(nms_bbox[result_index-1][1])
                
        
        nms_bbox_=[] 
        nms_bbox_.append(nms_bbox[0])    
        x_left_limit=nms_bbox[0][0]
        x_right_limit=nms_bbox[0][1]
        result_index=0
        
        for tt in np.arange(1, len(nms_bbox)):
            
            if x_left_limit < nms_bbox[tt][0]:
                nms_bbox_.append(nms_bbox[tt])
                x_left_limit=nms_bbox[tt][0]
            
            else:
                pass
        
            # if (x_right_limit < nms_bbox[tt][0]) & (nms_bbox[tt][1] < 1000):
                
            #     nms_bbox_.append(nms_bbox[tt])
            #     x_left_limit=nms_bbox[tt][0]
            #     x_right_limit=nms_bbox[tt][1]
            #     result_index=result_index+1
                
            # elif (x_left_limit < nms_bbox[tt][0]) & (nms_bbox[tt][0]<=x_right_limit):
                
            #     nms_bbox_[result_index][1]=nms_bbox[tt][1]
            #     x_right_limit=nms_bbox[tt][1]
            
            # else:
            #     pass
                
            
            
        nms_bbox = nms_bbox_    
    
        proposal_boxes.append(nms_bbox)
        
    return proposal_boxes



def get_proposal_bboxes_1st(DataLength_tf, rpn_reg_tf, rpn_cls_tf, anchors):
    
    nms_rflx_no=10
    
    proposal_boxes=[]
    
    for kk in np.arange(DataLength_tf):
                
        cls_score=rpn_cls_tf[kk]
        nms_reg=rpn_reg_tf[kk]
        
        cls_order_index=cls_score.ravel().argsort()
        cls_order_index=np.flip(cls_order_index)[0:nms_rflx_no]
        cls_order_index.sort()

        cls_score=cls_score[cls_order_index]
        cls_score=cls_score.squeeze()
        
        cls_order_index=tf.constant(cls_order_index, dtype=tf.int32)
        nms_anc_slice = tf.gather(anchors, cls_order_index)
        
        nms_anc_width=nms_anc_slice[...,1]-nms_anc_slice[...,0]
        nms_anc_ctr_x=nms_anc_slice[...,0]+0.5*nms_anc_width
        
        nms_bbox_width=tf.exp(nms_reg[cls_order_index, 1]) * nms_anc_width
        nms_bbox_ctr_x = (nms_reg[cls_order_index, 0] * nms_anc_width) + nms_anc_ctr_x
        
        x1 = nms_bbox_ctr_x - (0.5 * nms_bbox_width)
        x2 = x1 + nms_bbox_width
        
        result_index=0
        ctr_x_prev=0
        cls_score_prev=0
        
        nms_bbox=[]
        
        for tt in np.arange(nms_rflx_no):
    
            if cls_score[tt] > 0.549:
                
                if result_index==0:
                    
                    nms_bbox.append(np.array((x1[tt],x2[tt])).astype(np.float32))
                    result_index=result_index+1
                    ctr_x_prev=(x1[tt]+x2[tt])/2
                    cls_score_prev=cls_score[tt]
                
                else:
                    
                    if nms_bbox_ctr_x[tt]-ctr_x_prev > 30:
                        
                        nms_bbox.append(np.array((x1[tt],x2[tt])).astype(np.float32))
                        result_index=result_index+1
                        ctr_x_prev=(x1[tt]+x2[tt])/2
                        cls_score_prev=cls_score[tt]
                        
                    else:
                        
                        if cls_score[tt] >= (cls_score_prev+0.1):
                            
                            nms_bbox[result_index-1]=np.array((x1[tt],x2[tt])).astype(np.float32)
                            ctr_x_prev=(x1[tt]+x2[tt])/2
                            cls_score_prev=cls_score[tt]
                            
                        elif cls_score[tt] <= (cls_score_prev-0.1):
                            
                            pass
                            
                        else: 
                            
                            x1_expan=min(nms_bbox[result_index-1][0], x1[tt])
                            x2_expan=max(nms_bbox[result_index-1][1], x2[tt])
                            nms_bbox[result_index-1]=np.array((x1_expan,x2_expan)).astype(np.float32)
                            
                            ctr_x_prev=(x1_expan+x2_expan)/2
                            ctr_x_prev=max(ctr_x_prev,cls_score[tt])
                            
                            
                nms_bbox[result_index-1][0]=np.floor(nms_bbox[result_index-1][0])
                nms_bbox[result_index-1][1]=np.ceil(nms_bbox[result_index-1][1])
                
        
        nms_bbox_=[] 
        nms_bbox_.append(nms_bbox[0])    
        x_left_limit=nms_bbox[0][0]
        
        for tt in np.arange(1, len(nms_bbox)):
            
            if x_left_limit < nms_bbox[tt][0]:
                nms_bbox_.append(nms_bbox[tt])
                x_left_limit=nms_bbox[tt][0]
            
            else:
                pass
            
            
        nms_bbox = nms_bbox_    
    
        proposal_boxes.append(nms_bbox)
        
    return proposal_boxes


def get_proposal_bboxes_2nd(DataLength_tf, rpn_reg_tf, rpn_cls_tf, anchors):
    
    nms_rflx_no=10
    
    proposal_boxes=[]
    
    for kk in np.arange(DataLength_tf):
                
        cls_score=rpn_cls_tf[kk]
        nms_reg=rpn_reg_tf[kk]
        
        cls_order_index=cls_score.ravel().argsort()
        cls_order_index=np.flip(cls_order_index)[0:nms_rflx_no]
        cls_order_index.sort()

        cls_score=cls_score[cls_order_index]
        cls_score=cls_score.squeeze()
        
        cls_order_index=tf.constant(cls_order_index, dtype=tf.int32)
        nms_anc_slice = tf.gather(anchors, cls_order_index)
        
        nms_anc_width=nms_anc_slice[...,1]-nms_anc_slice[...,0]
        nms_anc_ctr_x=nms_anc_slice[...,0]+0.5*nms_anc_width
        
        nms_bbox_width=tf.exp(nms_reg[cls_order_index, 1]) * nms_anc_width
        nms_bbox_ctr_x = (nms_reg[cls_order_index, 0] * nms_anc_width) + nms_anc_ctr_x
        
        x1 = nms_bbox_ctr_x - (0.5 * nms_bbox_width)
        x2 = x1 + nms_bbox_width
        
        result_index=0
        ctr_x_prev=0
        cls_score_prev=0
        
        nms_bbox=[]
        
        #print(kk)
        
        for tt in np.arange(nms_rflx_no):
    
            if cls_score[tt] >= 0.10:
                
                if result_index==0:
                    
                    nms_bbox.append(np.array((x1[tt],x2[tt])).astype(np.float32))
                    result_index=result_index+1
                    ctr_x_prev=(x1[tt]+x2[tt])/2
                    cls_score_prev=cls_score[tt]
                
                else:
                    
                    if nms_bbox_ctr_x[tt]-ctr_x_prev > 30:
                        
                        nms_bbox.append(np.array((x1[tt],x2[tt])).astype(np.float32))
                        result_index=result_index+1
                        ctr_x_prev=(x1[tt]+x2[tt])/2
                        cls_score_prev=cls_score[tt]
                        
                    else:
                        
                        if cls_score[tt] >= (cls_score_prev+0.1):
                            
                            nms_bbox[result_index-1]=np.array((x1[tt],x2[tt])).astype(np.float32)
                            ctr_x_prev=(x1[tt]+x2[tt])/2
                            cls_score_prev=cls_score[tt]
                            
                        elif cls_score[tt] <= (cls_score_prev-0.1):
                            
                            pass
                            
                        else: 
                            
                            x1_expan=min(nms_bbox[result_index-1][0], x1[tt])
                            x2_expan=max(nms_bbox[result_index-1][1], x2[tt])
                            nms_bbox[result_index-1]=np.array((x1_expan,x2_expan)).astype(np.float32)
                            
                            ctr_x_prev=(x1_expan+x2_expan)/2
                            ctr_x_prev=max(ctr_x_prev,cls_score[tt])
                            
                            
                nms_bbox[result_index-1][0]=np.floor(nms_bbox[result_index-1][0])
                nms_bbox[result_index-1][1]=np.ceil(nms_bbox[result_index-1][1])
                
        
        nms_bbox_=[] 
        nms_bbox_.append(nms_bbox[0])    
        x_left_limit=nms_bbox[0][0]
        
        for tt in np.arange(1, len(nms_bbox)):
            
            if x_left_limit < nms_bbox[tt][0]:
                nms_bbox_.append(nms_bbox[tt])
                x_left_limit=nms_bbox[tt][0]
            
            else:
                pass
            
            
        nms_bbox = nms_bbox_    
    
        proposal_boxes.append(nms_bbox)
        
    return proposal_boxes


def get_rflx_position(DataLength_tf, rpn_bbox, WaveData_tf, rflx_res_1st, rflx_res_2nd):
    
    offset=5 # off-set for second order derivative (device dependent)
    
    rflx_res=[]
    rflx_num=np.zeros(shape=(DataLength_tf,1))
    
    for kk in np.arange(DataLength_tf):
        
        waveform_rpn_each=WaveData_tf[kk]
        waveform_rpn_each=waveform_rpn_each.squeeze()
        rpn_each=rpn_bbox[kk]
        length_each=len(rpn_each)
        
        rflx_num[kk]=length_each
        rflx_each=np.zeros((length_each,))
        
        rflx_1st_each=rflx_res_1st[kk]
        rflx_2nd_each=rflx_res_2nd[kk]
        
        for tt in np.arange(length_each):
        
            # the first refection position
            if tt==0:
    
                start_pt=int(rpn_each[tt][0])
                end_pt=int(rpn_each[tt][1]+1)
        
                oper_range=waveform_rpn_each[start_pt:end_pt]
        
                rflx_each[tt]=np.argmax(oper_range)+start_pt  
            
            # the final refection position
            elif tt==(length_each-1):
    
                start_pt=int(rpn_each[tt][0])
                end_pt=int(rpn_each[tt][1]+1)
                
                oper_range=waveform_rpn_each[start_pt:end_pt]   
                
                if len(oper_range)<=2:
                    
                    rflx_temp_1=start_pt+0.5-offset  
                    
                else:
                    
                    rflx_temp_1=np.argmax(np.diff(np.diff(oper_range)))+start_pt-offset     # should have a off-set here
                
                
                rflx_temp_2=start_pt+0.25*(end_pt-start_pt)
                rflx_each[tt]=0.5*(rflx_temp_1+rflx_temp_2)
                
            # the internal refection position
            else:
                
                start_pt=int(rpn_each[tt][0])
                end_pt=int(rpn_each[tt][1]+1)
                
                oper_range=waveform_rpn_each[start_pt:end_pt] 
                
                if len(oper_range)<=2:
                    
                    rflx_temp_1=start_pt+0.5-offset  
                    
                else:
                    
                    rflx_temp_1=np.argmax(np.diff(np.diff(oper_range)))+start_pt           # should have a off-set here but we do that later
                    
                    
                rflx_temp_2=start_pt+0.25*(end_pt-start_pt)
                
                if rflx_temp_2<rflx_temp_1:
                    
                    rflx_each[tt]=0.5*(rflx_temp_1+rflx_temp_2-offset)
                    
                else:
                    
                    rflx_each[tt]=rflx_temp_1-offset
                
        
        if length_each==1:
                        
            rflx_each=np.zeros((2,))
            rflx_each[0]=rflx_1st_each
            rflx_each[1]=rflx_2nd_each
            
            rflx_num[kk]=2
            
        elif length_each==2:
            
            if rflx_each[1]> (rflx_2nd_each+10):
                
                rflx_each[1]=rflx_2nd_each

        elif length_each==3:
            
            if rflx_each[1]> (rflx_2nd_each+10):
                
                rflx_each[1]=rflx_2nd_each
            
        else:
            
            for tt in np.flip(np.arange(length_each)):
                
                if rflx_each[tt]> (rflx_2nd_each+10):
                    
                    rflx_each=rflx_each[:-1]
                    rflx_num[kk]=rflx_num[kk]-1
            
            length_each=len(rflx_each)
            
            rflx_each[length_each-1]=min(rflx_each[length_each-1], rflx_2nd_each)
            rflx_res_2nd[kk]=rflx_each[length_each-1]
            
        rflx_res.append(rflx_each) 

    return rflx_res, rflx_num, rflx_res_2nd     

def get_rflx_position_1st(DataLength_tf, rpn_bbox, WaveData_tf):
    
    offset_1st=1.6 # off-set for second order derivative (device dependent)
    rflx_res_1st=np.zeros(shape=(DataLength_tf,1))
    
    for kk in np.arange(DataLength_tf):
        
        waveform_rpn_each=WaveData_tf[kk]
        waveform_rpn_each=waveform_rpn_each.squeeze()
        rpn_each=rpn_bbox[kk]
        start_pt=int(rpn_each[0][0])
        end_pt=int(rpn_each[0][1]+1)
        oper_range=waveform_rpn_each[start_pt:end_pt]
        rflx_res_1st[kk]=np.argmax(oper_range)+start_pt-offset_1st        

    return rflx_res_1st  


def get_rflx_position_2nd(DataLength_tf, rpn_bbox, WaveData_tf):
    
    offset=5 # off-set for second order derivative (device dependent)
    
    rflx_res_2nd=np.zeros(shape=(DataLength_tf,1))
    
    for kk in np.arange(DataLength_tf):
        
        waveform_rpn_each=WaveData_tf[kk]
        waveform_rpn_each=waveform_rpn_each.squeeze()
        rpn_each=rpn_bbox[kk]
        length_each=len(rpn_each)
        rflx_each=np.zeros((length_each,))
        
        for tt in np.arange(length_each):
            
            # the final refection position
            if tt==(length_each-1):
    
                start_pt=int(rpn_each[tt][0])
                end_pt=int(rpn_each[tt][1]+1)
                
                oper_range=waveform_rpn_each[start_pt:end_pt]              
                
                rflx_temp_1=np.argmax(np.diff(np.diff(oper_range)))+start_pt-offset     # should have a off-set here
                rflx_temp_2=start_pt+0.25*(end_pt-start_pt)
                
                rflx_each[tt]=0.5*(rflx_temp_1+rflx_temp_2)
                
            # the internal refection position
            else:
                
                start_pt=int(rpn_each[tt][0])
                end_pt=int(rpn_each[tt][1]+1)
                
                oper_range=waveform_rpn_each[start_pt:end_pt]              
                
                rflx_temp_1=np.argmax(np.diff(np.diff(oper_range)))+start_pt           # should have a off-set here but we do that later
                rflx_temp_2=start_pt+0.25*(end_pt-start_pt)
                
                if rflx_temp_2<rflx_temp_1:
                    
                    rflx_each[tt]=0.5*(rflx_temp_1+rflx_temp_2-offset)
                    
                else:
                    
                    rflx_each[tt]=rflx_temp_1-offset
                
        rflx_res_2nd[kk]=max(rflx_each)

    return rflx_res_2nd
