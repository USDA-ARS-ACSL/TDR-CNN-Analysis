# -*- coding: utf-8 -*-
"""
Created on Thu Jul  7 13:12:11 2022

@author: Zhuangji.Wang
"""

import pickle
with open('D:/PDE_ANN/Waveform_Rpn/TrainHistory_RPN_TDR_1D', 'rb') as file_pi:
    history_reload=pickle.load(file_pi)
    file_pi.close()
    
Loss_reg=history_reload['conv1d_49_loss']
Loss_cls=history_reload['conv1d_50_loss']


import numpy as np

x=np.arange(len(Loss_reg))


import matplotlib.pyplot as plt

fig, host = plt.subplots(figsize=(10,4))

#plt.rcParams['font.size'] = '28'
plt.rcParams['font.family'] = 'Times New Roman'

ax_r = host.twinx()

host.plot(x, Loss_cls,'g-')


ax_r.plot(x, Loss_reg,'b-')


host.set_yscale('linear')
ax_r.set_yscale('log')

#host.set_xlabel("Training Epochs")
host.set_ylabel("Cross-entrop Loss")
ax_r.set_ylabel("Huber Loss")


host.yaxis.label.set_color('g')
ax_r.yaxis.label.set_color('b')

host.spines["left"].set_edgecolor('g')
ax_r.spines["right"].set_edgecolor('b')

host.tick_params(axis='y', colors='g')
ax_r.tick_params(axis='y', colors='b')

plt.show()

fig.savefig('Error_plot.png', dpi=600)