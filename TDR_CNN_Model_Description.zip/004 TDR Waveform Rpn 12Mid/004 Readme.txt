You will need to train the RPN_TDR here, or you can use "myRPN1D_H5" for all reflection postions, "myRPN1D_H5_1st" for the first reflection positions and "myRPN1D_H5_2nd" for the second reflection positions
1. "RPN_TDR_1D.py" is the main code
2. At the beginning of "CNN_TDR_1D.py", you see 
	"WaveData_1sec=pd.read_csv('XXXsec_WaveForm.csv', header=None).astype(np.float32)
	WaveRflx_1sec=pd.read_csv('XXXsec_Reflx.csv', header=None).astype(np.float32)" 
	That means you will need to copy those data from 002 to this folder
3. In the middle of the code, you see
	"model_pretrain=tf.keras.models.load_model('myVGG1D_H5')"
	That means you need to copy "myVGG1D_H5" from 003 to this folder
4. The main results are
    "myRPN1D_H5" for all reflection postions, 
	"myRPN1D_H5_1st" for the first reflection positions
	"myRPN1D_H5_2nd" for the second reflection positions
5. The code will also generate some csv files, which is the reflection positions identified by the RPN_TDR model
