#!/usr/bin/env python
# coding: utf-8

# Step 2.1 utils anchor bbox generation and operations


import tensorflow as tf
import numpy as np


# # Generate the basic anchor box, only size specified, no position.
# def generate_base_anchors(hyper_params):
#     """Generating top left anchors for given anchor_ratios, anchor_scales and image size values.
#     inputs:
#         hyper_params = dictionary

#     outputs:
#         base_anchors = (anchor_count, [y1, x1, y2, x2])
#     """
    
#     """cauwzj: use [x1, x2] for 1D signal
#     """
    
#     wave_width = hyper_params["wave_width"]
#     anchor_scales = hyper_params["anchor_scales"]
#     base_anchors = []
#     for scale in anchor_scales:
#         scale /= wave_width
#         base_anchors.append([-scale / 2, scale / 2])
#     return tf.cast(base_anchors, dtype=tf.float32)


# Generate a seq of anchor boxes, position specified.
def generate_anchors(hyper_params):
    """Broadcasting base_anchors and generating all anchors for given image parameters.
    inputs:
        hyper_params = dictionary

    outputs:
        anchors = (output_width * output_height * anchor_count, [y1, x1, y2, x2])
            these values in normalized format between [0, 1]
    """
    
    """cauwzj: use [x1, x2] for 1D signal
    """
    
    # collect necessary parameters
    wave_width = hyper_params["wave_width"]
    anchor_scales = hyper_params["anchor_scales"]
    feature_map_shape = hyper_params["feature_map_shape"]
    
    # cast every dimension to 0-1 for easy computation, based on wave_width
    # basic anchors with scale
    base_anchors = []
    for scale in anchor_scales:
        scale /= wave_width
        base_anchors.append([-scale / 2.0, scale / 2.0])
    # place basic anchors to the dimension
    stride = 1.0 / feature_map_shape
    grid_coords = tf.cast(tf.range(0.0, feature_map_shape) / feature_map_shape + stride / 2.0, dtype=tf.float32)
    grid_map = tf.stack([grid_coords, grid_coords], axis=-1)
    
    anchors = tf.reshape(base_anchors, (1, -1, 2)) + tf.reshape(grid_map, (-1, 1, 2))
    anchors = tf.reshape(anchors, (-1, 2))
    
    # clip anchors outside of the wave_width and return to the original wavewidth
    anchors = tf.clip_by_value(anchors, 0, 1) * wave_width

    return anchors
    


# Applying non maximum suppression. Directly use tf.function



def non_max_suppression(pred_bboxes, pred_labels, **kwargs):
    """Applying non maximum suppression.
    Details could be found on tensorflow documentation.
    https://www.tensorflow.org/api_docs/python/tf/image/combined_non_max_suppression
    inputs:
        pred_bboxes = (batch_size, total_bboxes, total_labels, [y1, x1, y2, x2])
            total_labels should be 1 for binary operations like in rpn
        pred_labels = (batch_size, total_bboxes, total_labels)
        **kwargs = other parameters

    outputs:
        nms_boxes = (batch_size, max_detections, [y1, x1, y2, x2])
        nmsed_scores = (batch_size, max_detections)
        nmsed_classes = (batch_size, max_detections)
        valid_detections = (batch_size)
            Only the top valid_detections[i] entries in nms_boxes[i], nms_scores[i] and nms_class[i] are valid.
            The rest of the entries are zero paddings.
    """
    
    """cauwzj: use [x1, x2] and [delta_x, delta_w] for 1D signal
    """
    return tf.image.combined_non_max_suppression(
        pred_bboxes,
        pred_labels,
        **kwargs
    )


# Calculating bounding boxes for given bounding box and delta values.



def get_bboxes_from_deltas(anchors, deltas, select_index):
    """Calculating bounding boxes for given bounding box and delta values.
    inputs:
        anchors = (batch_size, total_bboxes, [y1, x1, y2, x2])
        deltas = (batch_size, total_bboxes, [delta_y, delta_x, delta_h, delta_w])

    outputs:
        final_boxes = (batch_size, total_bboxes, [y1, x1, y2, x2])
    """
    
    """cauwzj: use [x1, x2] and [delta_x, delta_w] for 1D signal
    """
    all_anc_width = anchors[..., 1] - anchors[..., 0]
    all_anc_ctr_x = anchors[..., 0] + 0.5 * all_anc_width
    #
    all_bbox_width = tf.exp(deltas[..., 1]) * all_anc_width
    all_bbox_ctr_x = (deltas[..., 0] * all_anc_width) + all_anc_ctr_x
    #
    x1 = all_bbox_ctr_x - (0.5 * all_bbox_width)
    x2 = all_bbox_width + x1
    #
    return tf.stack([x1, x2], axis=-1)


# Calculating bounding box deltas for given bounding box and ground truth boxes
def get_deltas_from_bboxes(bboxes, gt_boxes):
    """Calculating bounding box deltas for given bounding box and ground truth boxes.
    inputs:
        bboxes = (batch_size, total_bboxes, [y1, x1, y2, x2])
        gt_boxes = (batch_size, total_bboxes, [y1, x1, y2, x2])

    outputs:
        final_deltas = (batch_size, total_bboxes, [delta_y, delta_x, delta_h, delta_w])
    """
    
    """cauwzj: use [x1, x2] and [delta_x, delta_w] for 1D signal
    """
    bbox_width = bboxes[..., 1] - bboxes[..., 0]
    bbox_ctr_x = bboxes[..., 0] + 0.5 * bbox_width
    #
    gt_width = gt_boxes[..., 1] - gt_boxes[..., 0]
    gt_ctr_x = gt_boxes[..., 0] + 0.5 * gt_width
    #
    bbox_width = tf.where(tf.equal(bbox_width, 0), 1e-3, bbox_width)
    delta_x = tf.where(tf.equal(gt_width, 0), tf.zeros_like(gt_width), tf.truediv((gt_ctr_x - bbox_ctr_x), bbox_width))
    delta_w = tf.where(tf.equal(gt_width, 0), tf.zeros_like(gt_width), tf.math.log(gt_width / bbox_width))
    #
    return tf.stack([delta_x, delta_w], axis=-1)


# Calculating iou values for each ground truth boxes in batched manner.
def generate_iou_map(bboxes, gt_boxes):
    """Calculating iou values for each ground truth boxes in batched manner.
    inputs:
        bboxes = (batch_size, total_bboxes, [y1, x1, y2, x2])
        gt_boxes = (batch_size, total_gt_boxes, [y1, x1, y2, x2])

    outputs:
        iou_map = (batch_size, total_bboxes, total_gt_boxes)
    """
    
    """cauwzj: use [x1, x2] and [delta_x, delta_w] for 1D signal
    """
    
    bbox_x1, bbox_x2 = tf.split(bboxes, 2, axis=-1)
    gt_x1, gt_x2 = tf.split(gt_boxes, 2, axis=-1)
    # Calculate bbox and ground truth boxes areas
    gt_area = tf.squeeze((gt_x2 - gt_x1), axis=-1)
    bbox_area = tf.squeeze((bbox_x2 - bbox_x1), axis=-1)
    #
    x_top = tf.maximum(bbox_x1, tf.transpose(gt_x1, [1, 0]))
    x_bottom = tf.minimum(bbox_x2, tf.transpose(gt_x2, [1, 0]))
    ### Calculate intersection area
    intersection_area = tf.maximum(x_bottom - x_top, 0)
    ### Calculate union area
    union_area = (tf.expand_dims(bbox_area, -1) + tf.expand_dims(gt_area, 0) - intersection_area)
    # Intersection over Union
    return intersection_area / union_area


# Normalizing bounding boxes.


def normalize_bboxes(bboxes, height, width):
    """Normalizing bounding boxes.
    inputs:
        bboxes = (batch_size, total_bboxes, [y1, x1, y2, x2])
        height = image height
        width = image width
    outputs:
        normalized_bboxes = (batch_size, total_bboxes, [y1, x1, y2, x2])
            in normalized form [0, 1]
    """
    """cauwzj: use [x1, x2] and [delta_x, delta_w] for 1D signal
    """
    x1 = bboxes[..., 0] / width
    x2 = bboxes[..., 1] / width
    return tf.stack([x1, x2], axis=-1)


# Denormalizing bounding boxes.


def denormalize_bboxes(bboxes, height, width):
    """Denormalizing bounding boxes.
    inputs:
        bboxes = (batch_size, total_bboxes, [y1, x1, y2, x2])
            in normalized form [0, 1]
        height = image height
        width = image width
    outputs:
        denormalized_bboxes = (batch_size, total_bboxes, [y1, x1, y2, x2])
    """
    """cauwzj: use [x1, x2] and [delta_x, delta_w] for 1D signal
    """
    x1 = bboxes[..., 0] * width
    x2 = bboxes[..., 1] * width
    return tf.round(tf.stack([x1, x2], axis=-1))
