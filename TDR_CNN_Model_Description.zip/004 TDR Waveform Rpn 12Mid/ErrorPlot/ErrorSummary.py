# -*- coding: utf-8 -*-
"""
Created on Thu Jul 14 11:38:01 2022

@author: Zhuangji.Wang
"""

import pickle
import numpy as np
with open('D:/PDE_ANN/Waveform_Rpn_12Mid/TrainHistory_RPN_TDR_1D', 'rb') as file_pi:
    history_reload=pickle.load(file_pi)
    file_pi.close()

Loss1=history_reload['conv1d_92_loss']
Loss2=history_reload['conv1d_93_loss']

Results=np.array((Loss1, Loss2))

np.savetxt("ErrorAll.csv", Results, delimiter=",")


with open('D:/PDE_ANN/Waveform_Rpn_12Mid/TrainHistory_RPN_TDR_1D_1st', 'rb') as file_pi:
    history_reload=pickle.load(file_pi)
    file_pi.close()

Loss1=history_reload['conv1d_82_loss']
Loss2=history_reload['conv1d_83_loss']

Results=np.array((Loss1, Loss2))

np.savetxt("Error_1st.csv", Results, delimiter=",")

with open('D:/PDE_ANN/Waveform_Rpn_12Mid/TrainHistory_RPN_TDR_1D_2nd', 'rb') as file_pi:
    history_reload=pickle.load(file_pi)
    file_pi.close()

Loss1=history_reload['conv1d_63_loss']
Loss2=history_reload['conv1d_64_loss']

Results=np.array((Loss1, Loss2))

np.savetxt("Error_2nd.csv", Results, delimiter=",")