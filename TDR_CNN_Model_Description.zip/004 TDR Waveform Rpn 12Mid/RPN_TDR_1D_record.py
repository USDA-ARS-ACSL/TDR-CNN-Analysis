import sys
import numpy as np
import pandas as pd
import tensorflow as tf
# import sklearn as skl

np.set_printoptions(threshold=sys.maxsize)


###############################################################################
# Prepare necessary dataset for TDR RPN training

WaveData_1sec=pd.read_csv('1sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_1sec=pd.read_csv('1sec_Reflx.csv', header=None).astype(np.float32)

WaveData_1sec=WaveData_1sec.to_numpy(copy=True)
WaveRflx_1sec=WaveRflx_1sec.to_numpy(copy=True)

DataLength_1sec, WaveWidth_1sec=WaveData_1sec.shape
_, Rflx_Num_1sec=WaveRflx_1sec.shape
WaveData_1sec=WaveData_1sec.reshape((DataLength_1sec, WaveWidth_1sec))

WaveData_2sec=pd.read_csv('2sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_2sec=pd.read_csv('2sec_Reflx.csv', header=None).astype(np.float32)

WaveData_2sec=WaveData_2sec.to_numpy(copy=True)
WaveRflx_2sec=WaveRflx_2sec.to_numpy(copy=True)

DataLength_2sec, WaveWidth_2sec=WaveData_2sec.shape
_, Rflx_Num_2sec=WaveRflx_2sec.shape
WaveData_2sec=WaveData_2sec.reshape((DataLength_2sec, WaveWidth_2sec))

WaveData_3sec=pd.read_csv('3sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_3sec=pd.read_csv('3sec_Reflx.csv', header=None).astype(np.float32)

WaveData_3sec=WaveData_3sec.to_numpy(copy=True)
WaveRflx_3sec=WaveRflx_3sec.to_numpy(copy=True)

DataLength_3sec, WaveWidth_3sec=WaveData_3sec.shape
_, Rflx_Num_3sec=WaveRflx_3sec.shape
WaveData_3sec=WaveData_3sec.reshape((DataLength_3sec, WaveWidth_3sec))

WaveData_4sec=pd.read_csv('4sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_4sec=pd.read_csv('4sec_Reflx.csv', header=None).astype(np.float32)

WaveData_4sec=WaveData_4sec.to_numpy(copy=True)
WaveRflx_4sec=WaveRflx_4sec.to_numpy(copy=True)

DataLength_4sec, WaveWidth_4sec=WaveData_4sec.shape
_, Rflx_Num_4sec=WaveRflx_4sec.shape
WaveData_4sec=WaveData_4sec.reshape((DataLength_4sec, WaveWidth_4sec))

WaveData_tf=[]
RflxData_tf=[]
LbelData_tf=[]
#
for kk in np.arange(DataLength_1sec):
    wf=tf.convert_to_tensor(WaveData_1sec[kk].reshape((WaveWidth_1sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_1sec):
        if mm==0:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-20,WaveRflx_1sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-10,WaveRflx_1sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-15,WaveRflx_1sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_2sec):
    wf=tf.convert_to_tensor(WaveData_2sec[kk].reshape((WaveWidth_2sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_2sec):
        if mm==0:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-20,WaveRflx_2sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-10,WaveRflx_2sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-15,WaveRflx_2sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_3sec):
    wf=tf.convert_to_tensor(WaveData_3sec[kk].reshape((WaveWidth_3sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_3sec):
        if mm==0:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-20,WaveRflx_3sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-10,WaveRflx_3sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-15,WaveRflx_3sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,3,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_4sec):
    wf=tf.convert_to_tensor(WaveData_4sec[kk].reshape((WaveWidth_4sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_4sec):
        if mm==0:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-20,WaveRflx_4sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-10,WaveRflx_4sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-15,WaveRflx_4sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,3,3,2)).astype(np.int64)))

DataLength_tf=DataLength_1sec+DataLength_2sec+DataLength_3sec+DataLength_4sec
WaveWidth_tf=WaveWidth_1sec
WaveData_tf=np.asarray(WaveData_tf)

# Finish prepare the dataset

###############################################################################
# preload the TDR_CNN model 
model_pretrain=tf.keras.models.load_model('myVGG1D_H5')
Layer_Conv_1_Kernel=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[0])
Layer_Conv_1_Bias=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[1])
Layer_Conv_2_Kernel=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[0])
Layer_Conv_2_Bias=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[1])
Layer_Conv_3_Kernel=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[0])
Layer_Conv_3_Bias=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[1])
Layer_Conv_4_Kernel=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[0])
Layer_Conv_4_Bias=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[1])

base_model=tf.keras.Sequential([
    tf.keras.layers.InputLayer(input_shape=(WaveWidth_tf,1)),
    tf.keras.layers.Conv1D(filters=6, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_1_Kernel, bias_initializer=Layer_Conv_1_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=12, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_2_Kernel, bias_initializer=Layer_Conv_2_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=18, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_3_Kernel, bias_initializer=Layer_Conv_3_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=24, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_4_Kernel, bias_initializer=Layer_Conv_4_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
])

for layer in base_model.layers:
    layer.trainable=False

# the waveform feature has dimension 40000(datapoint)*62(spatial point)*16(features) or 24(features)
WaveFeature_tf=base_model.predict(WaveData_tf)


###############################################################################
# prepare the box dataset 
import bbox_utils, train_utils

hyper_params=train_utils.get_hyper_params()
# We add 1 class for background
hyper_params["total_labels"]=3+1 

for kk in np.arange(DataLength_tf):
    LbelData_tf[kk]=LbelData_tf[kk]
    
# create the anchor boxes    
anchors = bbox_utils.generate_anchors(hyper_params)    

feature_map_shape = hyper_params["feature_map_shape"]
anchor_count = hyper_params["anchor_count"]
total_pos_bboxes = hyper_params["total_pos_bboxes"]
total_neg_bboxes = hyper_params["total_neg_bboxes"]
variances = hyper_params["variances"]

pos_iou_threshold = 0.59
neg_iou_threshold = 0.41

n_sample = 16
pos_ratio = 0.5

for kk in np.arange(DataLength_tf):
#    waveform=WaveData_tf[kk]
    
    gt_boxes=RflxData_tf[kk]
    gt_labels=LbelData_tf[kk]
    batch_size = tf.shape(gt_boxes)[0]    
    
    iou_map = bbox_utils.generate_iou_map(anchors, gt_boxes)
    
    # operate along axis 0
    gt_argmax_col = tf.argmax(iou_map, axis=0, output_type=tf.int32)
    gt_max_col = tf.gather_nd(iou_map, indices=tf.stack([gt_argmax_col,tf.constant(np.arange(0,batch_size))],axis=1))
    gt_argmax_col = tf.constant(np.where(iou_map==gt_max_col)[0])

    # operate along axis 1
    gt_argmax_row = tf.argmax(iou_map, axis=1, output_type=tf.int32)
    gt_max_row = tf.gather_nd(iou_map, indices=tf.stack([tf.constant(np.arange(0,feature_map_shape)),gt_argmax_row],axis=1))
    
    # prepare label for training
    label=tf.zeros(shape=(feature_map_shape,), dtype=tf.int32)
    label=tf.where(gt_max_row>pos_iou_threshold,2,label)
    label=tf.where(gt_max_row<neg_iou_threshold,1,label)
    label=label-1
    label=tf.tensor_scatter_nd_update(label,tf.expand_dims(gt_argmax_col,axis=1), tf.ones(shape=tf.shape(gt_argmax_col), dtype=tf.int32))

    
    n_pos = pos_ratio * n_sample
    pos_index = np.where(label == 1)[0]
    if len(pos_index) > n_pos:
        disable_index = np.random.choice(pos_index, size=(len(pos_index) - int(n_pos)), replace=False)
        label=tf.tensor_scatter_nd_update(label, tf.expand_dims(disable_index,axis=1), \
                                          -1*tf.ones(shape=np.shape(disable_index), dtype=tf.int32))
    
    n_neg = n_sample * (1.0 - pos_ratio)
    neg_index = np.where(label == 0)[0]
    if len(neg_index) > n_neg:
        disable_index = np.random.choice(neg_index, size=(len(neg_index) - int(n_neg)), replace = False)
        label=tf.tensor_scatter_nd_update(label, tf.expand_dims(disable_index,axis=1), \
                                          -1*tf.ones(shape=np.shape(disable_index), dtype=tf.int32))
            
    gt_max_row_box = tf.gather_nd(gt_boxes, indices=tf.expand_dims(gt_argmax_row,axis=1))        
    gt_max_row_delta = bbox_utils.get_deltas_from_bboxes(anchors, gt_max_row_box) 
    
    index=tf.where(tf.not_equal(label, tf.constant(1, dtype=tf.int32)))
    
    index_=tf.concat([tf.concat([index,tf.zeros_like(index)],axis=1),tf.concat([index,tf.ones_like(index)],axis=1)],axis=0)
    
    
    gt_max_row_delta_ = tf.tensor_scatter_nd_update(gt_max_row_delta, index_, tf.zeros(shape=(tf.shape(index_)[0],), dtype=tf.float32))
    
    label_reshape=tf.reshape(label, [1,62,1])
    gt_max_row_delta_reshape=tf.reshape(gt_max_row_delta_, [1,62,2])
    
    if kk == 0:
        gt_Label_tf=label_reshape
        gt_BoxDelta_tf=gt_max_row_delta_reshape
    else:
        gt_Label_tf=tf.concat([gt_Label_tf,label_reshape],axis=0)
        gt_BoxDelta_tf=tf.concat([gt_BoxDelta_tf,gt_max_row_delta_reshape],axis=0)
            

##########################################################################################################################
#
# rpn_train_feed = train_utils.rpn_generator(DataLength_tf, WaveData_tf, RflxData_tf, LbelData_tf, anchors, hyper_params)


# Get model with fixed first several layers

# model_pretrain=tf.keras.models.load_model('myVGG1D_H5')
# Layer_Conv_1_Kernel=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[0])
# Layer_Conv_1_Bias=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[1])
# Layer_Conv_2_Kernel=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[0])
# Layer_Conv_2_Bias=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[1])
# Layer_Conv_3_Kernel=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[0])
# Layer_Conv_3_Bias=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[1])
# Layer_Conv_4_Kernel=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[0])
# Layer_Conv_4_Bias=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[1])

# base_model=tf.keras.Sequential([
#     tf.keras.layers.InputLayer(input_shape=(WaveWidth_tf,1)),
#     tf.keras.layers.Conv1D(filters=4, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_1_Kernel, bias_initializer=Layer_Conv_1_Bias),
#     tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
#     tf.keras.layers.Conv1D(filters=8, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_2_Kernel, bias_initializer=Layer_Conv_2_Bias),
#     tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
#     tf.keras.layers.Conv1D(filters=12, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_3_Kernel, bias_initializer=Layer_Conv_3_Bias),
#     tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
#     tf.keras.layers.Conv1D(filters=16, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_4_Kernel, bias_initializer=Layer_Conv_4_Bias),
#     tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
# ])

# for layer in base_model.layers:
#     layer.trainable=False

#output=tf.keras.layers.Conv1D(filters=25, kernel_size=3, strides=1, padding='same', activation='relu')(base_model.output)
#rpn_cls_output=tf.keras.layers.Conv1D(filters=hyper_params["anchor_count"], kernel_size=1, strides=1, padding='same', activation='sigmoid')(output)
#rpn_reg_output=tf.keras.layers.Conv1D(filters=hyper_params["anchor_count"]*2, (1, 1), activation="linear")(output)
#rpn_model = tf.keras.Model(inputs=base_model.input, outputs=[rpn_reg_output, rpn_cls_output])


#rpn_model.fit(rpn_train_feed, epochs=50)
###############################################################################
# establish the new part of model and start training
 
rpn_input=tf.keras.layers.Input(shape=(feature_map_shape,24))
rpn_conv1=tf.keras.layers.Conv1D(filters=24, kernel_size=3, strides=1, padding='same', activation='relu')(rpn_input)
rpn_reg=tf.keras.layers.Conv1D(filters=anchor_count*2, kernel_size=1, strides=1, padding='same', activation='linear')(rpn_conv1)
rpn_cls=tf.keras.layers.Conv1D(filters=anchor_count, kernel_size=1, strides=1, padding='same', activation='sigmoid')(rpn_conv1)
rpn_model = tf.keras.Model(inputs=rpn_input, outputs=[rpn_reg, rpn_cls])

# rpn_model.compile()
# rpn_model.summary()

# WaveRPN_tf=rpn_model.predict(WaveFeature_tf)
# rpn_reg, rpn_cls=WaveRPN_tf

# train_utils.cls_loss([gt_Label_tf,rpn_cls])
# train_utils.reg_loss([gt_BoxDelta_tf,rpn_reg])

rpn_model.compile(optimizer=tf.optimizers.Adam(learning_rate=1e-4), loss=[train_utils.reg_loss, train_utils.cls_loss])
history_rpn=rpn_model.fit(WaveFeature_tf, [gt_BoxDelta_tf, gt_Label_tf], epochs=150)


tf.keras.models.save_model(rpn_model,'myRPN1D_H5',save_format='h5')

import pickle
with open('D:/PDE_ANN/Waveform_Rpn/TrainHistory_RPN_TDR_1D', 'wb') as file_pi:
    pickle.dump(history_rpn.history, file_pi)
    file_pi.close()
    



WaveRPN_tf=rpn_model.predict(WaveFeature_tf)
rpn_reg, rpn_cls=WaveRPN_tf