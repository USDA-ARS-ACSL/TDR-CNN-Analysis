import sys
import numpy as np
import pandas as pd
import tensorflow as tf
# import sklearn as skl

np.set_printoptions(threshold=sys.maxsize)


###############################################################################
# Prepare necessary dataset for TDR RPN training

WaveData_1sec=pd.read_csv('1sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_1sec=pd.read_csv('1sec_Reflx.csv', header=None).astype(np.float32)

WaveData_1sec=WaveData_1sec.to_numpy(copy=True)
WaveRflx_1sec=WaveRflx_1sec.to_numpy(copy=True)

WaveData_1sec=(WaveData_1sec+1)/2.5

DataLength_1sec, WaveWidth_1sec=WaveData_1sec.shape
_, Rflx_Num_1sec=WaveRflx_1sec.shape
WaveData_1sec=WaveData_1sec.reshape((DataLength_1sec, WaveWidth_1sec))

WaveData_2sec=pd.read_csv('2sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_2sec=pd.read_csv('2sec_Reflx.csv', header=None).astype(np.float32)

WaveData_2sec=WaveData_2sec.to_numpy(copy=True)
WaveRflx_2sec=WaveRflx_2sec.to_numpy(copy=True)

WaveData_2sec=(WaveData_2sec+1)/2.5

DataLength_2sec, WaveWidth_2sec=WaveData_2sec.shape
_, Rflx_Num_2sec=WaveRflx_2sec.shape
WaveData_2sec=WaveData_2sec.reshape((DataLength_2sec, WaveWidth_2sec))

WaveData_3sec=pd.read_csv('3sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_3sec=pd.read_csv('3sec_Reflx.csv', header=None).astype(np.float32)

WaveData_3sec=WaveData_3sec.to_numpy(copy=True)
WaveRflx_3sec=WaveRflx_3sec.to_numpy(copy=True)

WaveData_3sec=(WaveData_3sec+1)/2.5

DataLength_3sec, WaveWidth_3sec=WaveData_3sec.shape
_, Rflx_Num_3sec=WaveRflx_3sec.shape
WaveData_3sec=WaveData_3sec.reshape((DataLength_3sec, WaveWidth_3sec))

WaveData_4sec=pd.read_csv('4sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_4sec=pd.read_csv('4sec_Reflx.csv', header=None).astype(np.float32)

WaveData_4sec=WaveData_4sec.to_numpy(copy=True)
WaveRflx_4sec=WaveRflx_4sec.to_numpy(copy=True)

WaveData_4sec=(WaveData_4sec+1)/2.5

DataLength_4sec, WaveWidth_4sec=WaveData_4sec.shape
_, Rflx_Num_4sec=WaveRflx_4sec.shape
WaveData_4sec=WaveData_4sec.reshape((DataLength_4sec, WaveWidth_4sec))

WaveData_tf=[]
RflxData_tf=[]
LbelData_tf=[]
#
for kk in np.arange(DataLength_1sec):
    wf=tf.convert_to_tensor(WaveData_1sec[kk].reshape((WaveWidth_1sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_1sec):
        if mm==0:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-20,WaveRflx_1sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-10,WaveRflx_1sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-15,WaveRflx_1sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_2sec):
    wf=tf.convert_to_tensor(WaveData_2sec[kk].reshape((WaveWidth_2sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_2sec):
        if mm==0:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-20,WaveRflx_2sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-10,WaveRflx_2sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-15,WaveRflx_2sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_3sec):
    wf=tf.convert_to_tensor(WaveData_3sec[kk].reshape((WaveWidth_3sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_3sec):
        if mm==0:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-20,WaveRflx_3sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-10,WaveRflx_3sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-15,WaveRflx_3sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,3,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_4sec):
    wf=tf.convert_to_tensor(WaveData_4sec[kk].reshape((WaveWidth_4sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_4sec):
        if mm==0:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-20,WaveRflx_4sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-10,WaveRflx_4sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-15,WaveRflx_4sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,3,3,2)).astype(np.int64)))

DataLength_tf=DataLength_1sec+DataLength_2sec+DataLength_3sec+DataLength_4sec
WaveWidth_tf=WaveWidth_1sec
WaveData_tf=np.asarray(WaveData_tf)

# Finish prepare the dataset

###############################################################################
# preload the TDR_CNN model 
model_pretrain=tf.keras.models.load_model('myVGG1D_H5')
Layer_Conv_1_Kernel=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[0])
Layer_Conv_1_Bias=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[1])
Layer_Conv_2_Kernel=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[0])
Layer_Conv_2_Bias=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[1])
Layer_Conv_3_Kernel=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[0])
Layer_Conv_3_Bias=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[1])
Layer_Conv_4_Kernel=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[0])
Layer_Conv_4_Bias=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[1])

base_model=tf.keras.Sequential([
    tf.keras.layers.InputLayer(input_shape=(WaveWidth_tf,1)),
    tf.keras.layers.Conv1D(filters=4, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_1_Kernel, bias_initializer=Layer_Conv_1_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=8, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_2_Kernel, bias_initializer=Layer_Conv_2_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=16, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_3_Kernel, bias_initializer=Layer_Conv_3_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=32, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_4_Kernel, bias_initializer=Layer_Conv_4_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
])

for layer in base_model.layers:
    layer.trainable=False

# the waveform feature has dimension 40000(datapoint)*62/50(spatial point)*16/24/32(features)
WaveFeature_tf=base_model.predict(WaveData_tf)


###############################################################################
# prepare the box dataset 
import bbox_utils, train_utils

hyper_params=train_utils.get_hyper_params()
# We add 1 class for background
hyper_params["total_labels"]=3+1 

for kk in np.arange(DataLength_tf):
    LbelData_tf[kk]=LbelData_tf[kk]
    
# create the anchor boxes    
anchors = bbox_utils.generate_anchors(hyper_params)    

feature_map_shape = hyper_params["feature_map_shape"]
anchor_count = hyper_params["anchor_count"]
total_pos_bboxes = hyper_params["total_pos_bboxes"]
total_neg_bboxes = hyper_params["total_neg_bboxes"]
variances = hyper_params["variances"]

pos_iou_threshold = 0.59
neg_iou_threshold = 0.41

n_sample = 16
pos_ratio = 0.5

n_sample_1st = 6#################################
pos_ratio_1st = 0.5#################################

n_sample_2nd = 6#################################
pos_ratio_2nd = 0.5#################################

for kk in np.arange(DataLength_tf):
#    waveform=WaveData_tf[kk]
    
    gt_boxes=RflxData_tf[kk]
    gt_labels=LbelData_tf[kk]
    batch_size = tf.shape(gt_boxes)[0]    
    
    iou_map = bbox_utils.generate_iou_map(anchors, gt_boxes)
    
    # operate along axis 0
    gt_argmax_col = tf.argmax(iou_map, axis=0, output_type=tf.int32)
    gt_max_col = tf.gather_nd(iou_map, indices=tf.stack([gt_argmax_col,tf.constant(np.arange(0,batch_size))],axis=1))
    gt_argmax_col = tf.constant(np.where(iou_map==gt_max_col)[0])

    # operate along axis 1
    gt_argmax_row = tf.argmax(iou_map, axis=1, output_type=tf.int32)
    gt_max_row = tf.gather_nd(iou_map, indices=tf.stack([tf.constant(np.arange(0,feature_map_shape)),gt_argmax_row],axis=1))
    
    # prepare label for training
    label=tf.zeros(shape=(feature_map_shape,), dtype=tf.int32)
    label=tf.where(gt_max_row>pos_iou_threshold,2,label)
    label=tf.where(gt_max_row<neg_iou_threshold,1,label)
    label=label-1
    label=tf.tensor_scatter_nd_update(label,tf.expand_dims(gt_argmax_col,axis=1), tf.ones(shape=tf.shape(gt_argmax_col), dtype=tf.int32))

    
    n_pos = pos_ratio * n_sample
    pos_index = np.where(label == 1)[0]
    if len(pos_index) > n_pos:
        disable_index = np.random.choice(pos_index, size=(len(pos_index) - int(n_pos)), replace=False)
        label=tf.tensor_scatter_nd_update(label, tf.expand_dims(disable_index,axis=1), \
                                          -1*tf.ones(shape=np.shape(disable_index), dtype=tf.int32))
    
    n_neg = n_sample * (1.0 - pos_ratio)
    neg_index = np.where(label == 0)[0]
    if len(neg_index) > n_neg:
        disable_index = np.random.choice(neg_index, size=(len(neg_index) - int(n_neg)), replace = False)
        label=tf.tensor_scatter_nd_update(label, tf.expand_dims(disable_index,axis=1), \
                                          -1*tf.ones(shape=np.shape(disable_index), dtype=tf.int32))
            
    gt_max_row_box = tf.gather_nd(gt_boxes, indices=tf.expand_dims(gt_argmax_row,axis=1))        
    gt_max_row_delta = bbox_utils.get_deltas_from_bboxes(anchors, gt_max_row_box) 
    
    index=tf.where(tf.not_equal(label, tf.constant(1, dtype=tf.int32)))
    index_=tf.concat([tf.concat([index,tf.zeros_like(index)],axis=1),tf.concat([index,tf.ones_like(index)],axis=1)],axis=0)
    gt_max_row_delta_ = tf.tensor_scatter_nd_update(gt_max_row_delta, index_, tf.zeros(shape=(tf.shape(index_)[0],), dtype=tf.float32))
    
    label_reshape=tf.reshape(label, [1,62,1])
    gt_max_row_delta_reshape=tf.reshape(gt_max_row_delta_, [1,62,2])
    
    if kk == 0:
        gt_Label_tf=label_reshape
        gt_BoxDelta_tf=gt_max_row_delta_reshape
    else:
        gt_Label_tf=tf.concat([gt_Label_tf,label_reshape],axis=0)
        gt_BoxDelta_tf=tf.concat([gt_BoxDelta_tf,gt_max_row_delta_reshape],axis=0)
        
        
    #########################################################################################
    
    gt_boxes_1st=RflxData_tf[kk][0]
    gt_boxes_1st=tf.expand_dims(gt_boxes_1st,axis=0)
    gt_labels_1st=1

    iou_map_1st = bbox_utils.generate_iou_map(anchors, gt_boxes_1st)

    # operate along axis 0
    gt_argmax_col_1st = tf.argmax(iou_map_1st, axis=0, output_type=tf.int32)
    gt_max_col_1st = tf.gather_nd(iou_map_1st, indices=tf.stack([gt_argmax_col_1st,tf.constant(np.arange(0,1))],axis=1))
    gt_argmax_col_1st = tf.constant(np.where(iou_map_1st==gt_max_col_1st)[0])

    # operate along axis 1
    gt_argmax_row_1st = tf.argmax(iou_map_1st, axis=1, output_type=tf.int32)
    gt_max_row_1st = tf.gather_nd(iou_map_1st, indices=tf.stack([tf.constant(np.arange(0,feature_map_shape)),gt_argmax_row_1st],axis=1))

    # prepare label for training
    label_1st=tf.zeros(shape=(feature_map_shape,), dtype=tf.int32)
    label_1st=tf.where(gt_max_row_1st>pos_iou_threshold,2,label_1st)
    label_1st=tf.where(gt_max_row_1st<neg_iou_threshold,1,label_1st)
    label_1st=label_1st-1
    label_1st=tf.tensor_scatter_nd_update(label_1st,tf.expand_dims(gt_argmax_col_1st,axis=1), tf.ones(shape=tf.shape(gt_argmax_col_1st), dtype=tf.int32))


    n_pos_1st = pos_ratio_1st * n_sample_1st
    pos_index_1st = np.where(label_1st == 1)[0]
    if len(pos_index_1st) > n_pos_1st:
        disable_index_1st = np.random.choice(pos_index_1st, size=(len(pos_index_1st) - int(n_pos_1st)), replace=False)
        label_1st=tf.tensor_scatter_nd_update(label_1st, tf.expand_dims(disable_index_1st,axis=1), \
                                          -1*tf.ones(shape=np.shape(disable_index_1st), dtype=tf.int32))

    n_neg_1st = n_sample_1st * (1.0 - pos_ratio_1st)
    neg_index_1st = np.where(label_1st == 0)[0]
    if len(neg_index_1st) > n_neg_1st:
        disable_index_1st = np.random.choice(neg_index_1st, size=(len(neg_index_1st) - int(n_neg_1st)), replace = False)
        label_1st=tf.tensor_scatter_nd_update(label_1st, tf.expand_dims(disable_index_1st,axis=1), \
                                          -1*tf.ones(shape=np.shape(disable_index_1st), dtype=tf.int32))
            
    gt_max_row_box_1st = tf.gather_nd(gt_boxes_1st, indices=tf.expand_dims(gt_argmax_row_1st,axis=1))        
    gt_max_row_delta_1st = bbox_utils.get_deltas_from_bboxes(anchors, gt_max_row_box_1st) 

    index_1st=tf.where(tf.not_equal(label_1st, tf.constant(1, dtype=tf.int32)))
    index_1st_=tf.concat([tf.concat([index_1st,tf.zeros_like(index_1st)],axis=1),tf.concat([index_1st,tf.ones_like(index_1st)],axis=1)],axis=0)
    gt_max_row_delta_1st_ = tf.tensor_scatter_nd_update(gt_max_row_delta_1st, index_1st_, tf.zeros(shape=(tf.shape(index_1st_)[0],), dtype=tf.float32))

    label_reshape_1st=tf.reshape(label_1st, [1,62,1])
    gt_max_row_delta_reshape_1st=tf.reshape(gt_max_row_delta_1st_, [1,62,2])
    
    if kk == 0:
        gt_Label_tf_1st=label_reshape_1st
        gt_BoxDelta_tf_1st=gt_max_row_delta_reshape_1st
    else:
        gt_Label_tf_1st=tf.concat([gt_Label_tf_1st,label_reshape_1st],axis=0)
        gt_BoxDelta_tf_1st=tf.concat([gt_BoxDelta_tf_1st,gt_max_row_delta_reshape_1st],axis=0)
        
    #########################################################################################
    
    gt_boxes_2nd=RflxData_tf[kk][batch_size-1]
    gt_boxes_2nd=tf.expand_dims(gt_boxes_2nd,axis=0)
    gt_labels_2nd=1

    iou_map_2nd = bbox_utils.generate_iou_map(anchors, gt_boxes_2nd)

    # operate along axis 0
    gt_argmax_col_2nd = tf.argmax(iou_map_2nd, axis=0, output_type=tf.int32)
    gt_max_col_2nd = tf.gather_nd(iou_map_2nd, indices=tf.stack([gt_argmax_col_2nd,tf.constant(np.arange(0,1))],axis=1))
    gt_argmax_col_2nd = tf.constant(np.where(iou_map_2nd==gt_max_col_2nd)[0])

    # operate along axis 1
    gt_argmax_row_2nd = tf.argmax(iou_map_2nd, axis=1, output_type=tf.int32)
    gt_max_row_2nd = tf.gather_nd(iou_map_2nd, indices=tf.stack([tf.constant(np.arange(0,feature_map_shape)),gt_argmax_row_2nd],axis=1))

    # prepare label for training
    label_2nd=tf.zeros(shape=(feature_map_shape,), dtype=tf.int32)
    label_2nd=tf.where(gt_max_row_2nd>pos_iou_threshold,2,label_2nd)
    label_2nd=tf.where(gt_max_row_2nd<neg_iou_threshold,1,label_2nd)
    label_2nd=label_2nd-1
    label_2nd=tf.tensor_scatter_nd_update(label_2nd,tf.expand_dims(gt_argmax_col_2nd,axis=1), tf.ones(shape=tf.shape(gt_argmax_col_2nd), dtype=tf.int32))


    n_pos_2nd = pos_ratio_2nd * n_sample_2nd
    pos_index_2nd = np.where(label_2nd == 1)[0]
    if len(pos_index_2nd) > n_pos_2nd:
        disable_index_2nd = np.random.choice(pos_index_2nd, size=(len(pos_index_2nd) - int(n_pos_2nd)), replace=False)
        label_2nd=tf.tensor_scatter_nd_update(label_2nd, tf.expand_dims(disable_index_2nd,axis=1), \
                                          -1*tf.ones(shape=np.shape(disable_index_2nd), dtype=tf.int32))

    n_neg_2nd = n_sample_2nd * (1.0 - pos_ratio_2nd)
    neg_index_2nd = np.where(label_2nd == 0)[0]
    if len(neg_index_2nd) > n_neg_2nd:
        disable_index_2nd = np.random.choice(neg_index_2nd, size=(len(neg_index_2nd) - int(n_neg_2nd)), replace = False)
        label_2nd=tf.tensor_scatter_nd_update(label_2nd, tf.expand_dims(disable_index_2nd,axis=1), \
                                          -1*tf.ones(shape=np.shape(disable_index_2nd), dtype=tf.int32))
            
    gt_max_row_box_2nd = tf.gather_nd(gt_boxes_2nd, indices=tf.expand_dims(gt_argmax_row_2nd,axis=1))        
    gt_max_row_delta_2nd = bbox_utils.get_deltas_from_bboxes(anchors, gt_max_row_box_2nd) 

    index_2nd=tf.where(tf.not_equal(label_2nd, tf.constant(1, dtype=tf.int32)))
    index_2nd_=tf.concat([tf.concat([index_2nd,tf.zeros_like(index_2nd)],axis=1),tf.concat([index_2nd,tf.ones_like(index_2nd)],axis=1)],axis=0)
    gt_max_row_delta_2nd_ = tf.tensor_scatter_nd_update(gt_max_row_delta_2nd, index_2nd_, tf.zeros(shape=(tf.shape(index_2nd_)[0],), dtype=tf.float32))

    label_reshape_2nd=tf.reshape(label_2nd, [1,62,1])
    gt_max_row_delta_reshape_2nd=tf.reshape(gt_max_row_delta_2nd_, [1,62,2])
    
    if kk == 0:
        gt_Label_tf_2nd=label_reshape_2nd
        gt_BoxDelta_tf_2nd=gt_max_row_delta_reshape_2nd
    else:
        gt_Label_tf_2nd=tf.concat([gt_Label_tf_2nd,label_reshape_2nd],axis=0)
        gt_BoxDelta_tf_2nd=tf.concat([gt_BoxDelta_tf_2nd,gt_max_row_delta_reshape_2nd],axis=0)
            

###############################################################################

## first train the whole net-work
 
rpn_input=tf.keras.layers.Input(shape=(feature_map_shape,32))
rpn_conv1=tf.keras.layers.Conv1D(filters=32, kernel_size=3, strides=1, padding='same', activation='relu')(rpn_input)
rpn_reg=tf.keras.layers.Conv1D(filters=anchor_count*2, kernel_size=1, strides=1, padding='same', activation='linear')(rpn_conv1)
rpn_cls=tf.keras.layers.Conv1D(filters=anchor_count, kernel_size=1, strides=1, padding='same', activation='sigmoid')(rpn_conv1)
rpn_model = tf.keras.Model(inputs=rpn_input, outputs=[rpn_reg, rpn_cls])

rpn_model.summary()

lr_rpn = tf.keras.optimizers.schedules.PiecewiseConstantDecay([500,1000,1500,2000],[1e-3,5e-4,1e-4,5e-5,1e-5])


rpn_model.compile(optimizer=tf.optimizers.Adam(learning_rate=lr_rpn), loss=[train_utils.reg_loss, train_utils.cls_loss])
history_rpn=rpn_model.fit(WaveFeature_tf, [gt_BoxDelta_tf, gt_Label_tf], epochs=3000)

# save model and history
tf.keras.models.save_model(rpn_model,'myRPN1D_H5',save_format='h5')

import pickle
with open('D:/PDE_ANN/Waveform_Rpn_12Mid/TrainHistory_RPN_TDR_1D', 'wb') as file_pi:
    pickle.dump(history_rpn.history, file_pi)
    file_pi.close()
    
# reload model if I have a good one
rpn_model=tf.keras.models.load_model('myRPN1D_H5',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})  
    
## second train the first reflection position    
    
rpn_input=tf.keras.layers.Input(shape=(feature_map_shape,32))
rpn_conv1=tf.keras.layers.Conv1D(filters=32, kernel_size=3, strides=1, padding='same', activation='relu')(rpn_input)
rpn_reg_1st=tf.keras.layers.Conv1D(filters=anchor_count*2, kernel_size=1, strides=1, padding='same', activation='linear')(rpn_conv1)
rpn_cls_1st=tf.keras.layers.Conv1D(filters=anchor_count, kernel_size=1, strides=1, padding='same', activation='sigmoid')(rpn_conv1)
rpn_model_1st = tf.keras.Model(inputs=rpn_input, outputs=[rpn_reg_1st, rpn_cls_1st])

rpn_model_1st.summary()

lr_1st = tf.keras.optimizers.schedules.PiecewiseConstantDecay([200,250,300,350],[1e-3,5e-4,1e-4,5e-5,1e-5])

rpn_model_1st.compile(optimizer=tf.optimizers.Adam(learning_rate=lr_1st), loss=[train_utils.reg_loss, train_utils.cls_loss])
history_rpn_1st=rpn_model_1st.fit(WaveFeature_tf, [gt_BoxDelta_tf_1st, gt_Label_tf_1st], epochs=400)

# save model and history
tf.keras.models.save_model(rpn_model_1st,'myRPN1D_H5_1st',save_format='h5')

import pickle
with open('D:/PDE_ANN/Waveform_Rpn_12Mid/TrainHistory_RPN_TDR_1D_1st', 'wb') as file_pi:
    pickle.dump(history_rpn_1st.history, file_pi)
    file_pi.close()  
    
# reload model if I have a good one
rpn_model_1st=tf.keras.models.load_model('myRPN1D_H5_1st',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})   
    
## third train the second reflection position    

rpn_input=tf.keras.layers.Input(shape=(feature_map_shape,32))
rpn_conv1=tf.keras.layers.Conv1D(filters=32, kernel_size=3, strides=1, padding='same', activation='relu')(rpn_input)
rpn_reg_2nd=tf.keras.layers.Conv1D(filters=anchor_count*2, kernel_size=1, strides=1, padding='same', activation='linear')(rpn_conv1)
rpn_cls_2nd=tf.keras.layers.Conv1D(filters=anchor_count, kernel_size=1, strides=1, padding='same', activation='sigmoid')(rpn_conv1)
rpn_model_2nd = tf.keras.Model(inputs=rpn_input, outputs=[rpn_reg_2nd, rpn_cls_2nd])

rpn_model_2nd.summary()

lr_2nd = tf.keras.optimizers.schedules.PiecewiseConstantDecay([200,250,300,350],[1e-3,5e-4,1e-4,5e-5,1e-5])

rpn_model_2nd.compile(optimizer=tf.optimizers.Adam(learning_rate=lr_2nd), loss=[train_utils.reg_loss, train_utils.cls_loss])
history_rpn_2nd=rpn_model_2nd.fit(WaveFeature_tf, [gt_BoxDelta_tf_2nd, gt_Label_tf_2nd], epochs=400)


# save model and history
tf.keras.models.save_model(rpn_model_2nd,'myRPN1D_H5_2nd',save_format='h5')

import pickle
with open('D:/PDE_ANN/Waveform_Rpn_12Mid/TrainHistory_RPN_TDR_1D_2nd', 'wb') as file_pi:
    pickle.dump(history_rpn_2nd.history, file_pi)
    file_pi.close()    

# reload model if I have a good one
rpn_model_2nd=tf.keras.models.load_model('myRPN1D_H5_2nd',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})   
    

    

WaveRPN_tf=rpn_model.predict(WaveFeature_tf)
rpn_reg_tf, rpn_cls_tf=WaveRPN_tf

WaveRPN_tf_1st=rpn_model_1st.predict(WaveFeature_tf)
rpn_reg_tf_1st, rpn_cls_tf_1st=WaveRPN_tf_1st

WaveRPN_tf_2nd=rpn_model_2nd.predict(WaveFeature_tf)
rpn_reg_tf_2nd, rpn_cls_tf_2nd=WaveRPN_tf_2nd


import wave_utils
###############################################################################
# first detect the 1st reflection position

rpn_bbox_1st = wave_utils.get_proposal_bboxes_1st(DataLength_tf, rpn_reg_tf_1st, rpn_cls_tf_1st, anchors)
rflx_res_1st = wave_utils.get_rflx_position_1st(DataLength_tf, rpn_bbox_1st, WaveData_tf)


###############################################################################
# second detect the 2nd reflection position

rpn_bbox_2nd = wave_utils.get_proposal_bboxes_2nd(DataLength_tf, rpn_reg_tf_2nd, rpn_cls_tf_2nd, anchors)
rflx_res_2nd = wave_utils.get_rflx_position_2nd(DataLength_tf, rpn_bbox_2nd, WaveData_tf)

    

##############################################################################
# third detect internal reflection positions
# using the first and second refection position as the pre-knowledge
 
rpn_bbox = wave_utils.get_proposal_bboxes(DataLength_tf, rpn_reg_tf, rpn_cls_tf, anchors)
rflx_res, rflx_num, rflx_res_2nd = wave_utils.get_rflx_position(DataLength_tf, rpn_bbox, WaveData_tf, rflx_res_1st, rflx_res_2nd)








###############################################################################

np.savetxt('rflx_num_1st.csv', rflx_res_1st, delimiter=',')
np.savetxt('rflx_num_2nd.csv', rflx_res_2nd, delimiter=',')


np.savetxt('rflx_num_2nd_01.csv', rflx_res_2nd[0000:10000], delimiter=',')
np.savetxt('rflx_num_2nd_02.csv', rflx_res_2nd[10000:20000], delimiter=',')
np.savetxt('rflx_num_2nd_03.csv', rflx_res_2nd[20000:30000], delimiter=',')
np.savetxt('rflx_num_2nd_04.csv', rflx_res_2nd[30000:40000], delimiter=',')



np.savetxt('rflx_num_01.csv', rflx_num[0000:10000], delimiter=',')
np.savetxt('rflx_num_02.csv', rflx_num[10000:20000], delimiter=',')
np.savetxt('rflx_num_03.csv', rflx_num[20000:30000], delimiter=',')
np.savetxt('rflx_num_04.csv', rflx_num[30000:40000], delimiter=',')

import csv

with open('rflx_res_01.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[0000:10000])
    
with open('rflx_res_02.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[10000:20000])
    
with open('rflx_res_03.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[20000:30000])
    
with open('rflx_res_04.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[30000:40000])


##############################################################################
# now we need to determine the relative premittivity for each section
    