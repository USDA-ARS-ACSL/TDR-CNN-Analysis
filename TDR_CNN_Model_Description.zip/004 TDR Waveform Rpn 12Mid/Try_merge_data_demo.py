# -*- coding: utf-8 -*-
"""
Created on Sun Jul 10 14:39:00 2022

@author: Zhuangji.Wang
"""

import sys
import numpy as np
import pandas as pd
import tensorflow as tf
# import sklearn as skl

np.set_printoptions(threshold=sys.maxsize)


###############################################################################
# Prepare necessary dataset for TDR RPN training

WaveData_1sec=pd.read_csv('1sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_1sec=pd.read_csv('1sec_Reflx.csv', header=None).astype(np.float32)

WaveData_1sec=WaveData_1sec.to_numpy(copy=True)
WaveRflx_1sec=WaveRflx_1sec.to_numpy(copy=True)

DataLength_1sec, WaveWidth_1sec=WaveData_1sec.shape
_, Rflx_Num_1sec=WaveRflx_1sec.shape
WaveData_1sec=WaveData_1sec.reshape((DataLength_1sec, WaveWidth_1sec))

WaveData_2sec=pd.read_csv('2sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_2sec=pd.read_csv('2sec_Reflx.csv', header=None).astype(np.float32)

WaveData_2sec=WaveData_2sec.to_numpy(copy=True)
WaveRflx_2sec=WaveRflx_2sec.to_numpy(copy=True)

DataLength_2sec, WaveWidth_2sec=WaveData_2sec.shape
_, Rflx_Num_2sec=WaveRflx_2sec.shape
WaveData_2sec=WaveData_2sec.reshape((DataLength_2sec, WaveWidth_2sec))

WaveData_3sec=pd.read_csv('3sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_3sec=pd.read_csv('3sec_Reflx.csv', header=None).astype(np.float32)

WaveData_3sec=WaveData_3sec.to_numpy(copy=True)
WaveRflx_3sec=WaveRflx_3sec.to_numpy(copy=True)

DataLength_3sec, WaveWidth_3sec=WaveData_3sec.shape
_, Rflx_Num_3sec=WaveRflx_3sec.shape
WaveData_3sec=WaveData_3sec.reshape((DataLength_3sec, WaveWidth_3sec))

WaveData_4sec=pd.read_csv('4sec_WaveForm.csv', header=None).astype(np.float32)
WaveRflx_4sec=pd.read_csv('4sec_Reflx.csv', header=None).astype(np.float32)

WaveData_4sec=WaveData_4sec.to_numpy(copy=True)
WaveRflx_4sec=WaveRflx_4sec.to_numpy(copy=True)

DataLength_4sec, WaveWidth_4sec=WaveData_4sec.shape
_, Rflx_Num_4sec=WaveRflx_4sec.shape
WaveData_4sec=WaveData_4sec.reshape((DataLength_4sec, WaveWidth_4sec))

WaveData_tf=[]
RflxData_tf=[]
LbelData_tf=[]
#
for kk in np.arange(DataLength_1sec):
    wf=tf.convert_to_tensor(WaveData_1sec[kk].reshape((WaveWidth_1sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_1sec):
        if mm==0:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-20,WaveRflx_1sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-10,WaveRflx_1sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_1sec[kk,mm]-15,WaveRflx_1sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_2sec):
    wf=tf.convert_to_tensor(WaveData_2sec[kk].reshape((WaveWidth_2sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_2sec):
        if mm==0:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-20,WaveRflx_2sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-10,WaveRflx_2sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_2sec[kk,mm]-15,WaveRflx_2sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_3sec):
    wf=tf.convert_to_tensor(WaveData_3sec[kk].reshape((WaveWidth_3sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_3sec):
        if mm==0:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-20,WaveRflx_3sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-10,WaveRflx_3sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_3sec[kk,mm]-15,WaveRflx_3sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,3,2)).astype(np.int64)))
#
for kk in np.arange(DataLength_4sec):
    wf=tf.convert_to_tensor(WaveData_4sec[kk].reshape((WaveWidth_4sec,1)))
    WaveData_tf.append(wf)   
    rf=[]
    for mm in np.arange(Rflx_Num_4sec):
        if mm==0:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-20,WaveRflx_4sec[kk,mm]+20)).astype(np.float32))
        elif mm==Rflx_Num_1sec-1:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-10,WaveRflx_4sec[kk,mm]+30)).astype(np.float32))
        else:
            rf.append(np.array((WaveRflx_4sec[kk,mm]-15,WaveRflx_4sec[kk,mm]+15)).astype(np.float32))
    rf=tf.convert_to_tensor(rf)
    RflxData_tf.append(rf)
    LbelData_tf.append(tf.convert_to_tensor(np.array((1,3,3,3,2)).astype(np.int64)))

DataLength_tf=DataLength_1sec+DataLength_2sec+DataLength_3sec+DataLength_4sec
WaveWidth_tf=WaveWidth_1sec
WaveData_tf=np.asarray(WaveData_tf)

# Finish prepare the dataset

###############################################################################
# preload the TDR_CNN model 
model_pretrain=tf.keras.models.load_model('myVGG1D_H5')
Layer_Conv_1_Kernel=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[0])
Layer_Conv_1_Bias=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[1])
Layer_Conv_2_Kernel=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[0])
Layer_Conv_2_Bias=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[1])
Layer_Conv_3_Kernel=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[0])
Layer_Conv_3_Bias=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[1])
Layer_Conv_4_Kernel=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[0])
Layer_Conv_4_Bias=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[1])

base_model=tf.keras.Sequential([
    tf.keras.layers.InputLayer(input_shape=(WaveWidth_tf,1)),
    tf.keras.layers.Conv1D(filters=6, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_1_Kernel, bias_initializer=Layer_Conv_1_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=12, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_2_Kernel, bias_initializer=Layer_Conv_2_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=18, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_3_Kernel, bias_initializer=Layer_Conv_3_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=24, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_4_Kernel, bias_initializer=Layer_Conv_4_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
])

for layer in base_model.layers:
    layer.trainable=False

# the waveform feature has dimension 40000(datapoint)*62/50(spatial point)*16/24(features)
WaveFeature_tf=base_model.predict(WaveData_tf)


###############################################################################
# prepare the box dataset 
import bbox_utils, train_utils

hyper_params=train_utils.get_hyper_params()
# We add 1 class for background
hyper_params["total_labels"]=3+1 

for kk in np.arange(DataLength_tf):
    LbelData_tf[kk]=LbelData_tf[kk]
    
# create the anchor boxes    
anchors = bbox_utils.generate_anchors(hyper_params)    

feature_map_shape = hyper_params["feature_map_shape"]
anchor_count = hyper_params["anchor_count"]
total_pos_bboxes = hyper_params["total_pos_bboxes"]
total_neg_bboxes = hyper_params["total_neg_bboxes"]
variances = hyper_params["variances"]

pos_iou_threshold = 0.59
neg_iou_threshold = 0.41

n_sample = 16
pos_ratio = 0.5

n_sample_1st = 6#################################
pos_ratio_1st = 0.5#################################

n_sample_2nd = 6#################################
pos_ratio_2nd = 0.5#################################


kk=15000

gt_boxes=RflxData_tf[kk]
gt_labels=LbelData_tf[kk]
batch_size = tf.shape(gt_boxes)[0]    

iou_map = bbox_utils.generate_iou_map(anchors, gt_boxes)

# operate along axis 0
gt_argmax_col = tf.argmax(iou_map, axis=0, output_type=tf.int32)
gt_max_col = tf.gather_nd(iou_map, indices=tf.stack([gt_argmax_col,tf.constant(np.arange(0,batch_size))],axis=1))
gt_argmax_col = tf.constant(np.where(iou_map==gt_max_col)[0])

# operate along axis 1
gt_argmax_row = tf.argmax(iou_map, axis=1, output_type=tf.int32)
gt_max_row = tf.gather_nd(iou_map, indices=tf.stack([tf.constant(np.arange(0,feature_map_shape)),gt_argmax_row],axis=1))

# prepare label for training
label=tf.zeros(shape=(feature_map_shape,), dtype=tf.int32)
label=tf.where(gt_max_row>pos_iou_threshold,2,label)
label=tf.where(gt_max_row<neg_iou_threshold,1,label)
label=label-1
label=tf.tensor_scatter_nd_update(label,tf.expand_dims(gt_argmax_col,axis=1), tf.ones(shape=tf.shape(gt_argmax_col), dtype=tf.int32))


n_pos = pos_ratio * n_sample
pos_index = np.where(label == 1)[0]
if len(pos_index) > n_pos:
    disable_index = np.random.choice(pos_index, size=(len(pos_index) - int(n_pos)), replace=False)
    label=tf.tensor_scatter_nd_update(label, tf.expand_dims(disable_index,axis=1), \
                                      -1*tf.ones(shape=np.shape(disable_index), dtype=tf.int32))

n_neg = n_sample * (1.0 - pos_ratio)
neg_index = np.where(label == 0)[0]
if len(neg_index) > n_neg:
    disable_index = np.random.choice(neg_index, size=(len(neg_index) - int(n_neg)), replace = False)
    label=tf.tensor_scatter_nd_update(label, tf.expand_dims(disable_index,axis=1), \
                                      -1*tf.ones(shape=np.shape(disable_index), dtype=tf.int32))
        
gt_max_row_box = tf.gather_nd(gt_boxes, indices=tf.expand_dims(gt_argmax_row,axis=1))        
gt_max_row_delta = bbox_utils.get_deltas_from_bboxes(anchors, gt_max_row_box) 

index=tf.where(tf.not_equal(label, tf.constant(1, dtype=tf.int32)))

index_=tf.concat([tf.concat([index,tf.zeros_like(index)],axis=1),tf.concat([index,tf.ones_like(index)],axis=1)],axis=0)


gt_max_row_delta_ = tf.tensor_scatter_nd_update(gt_max_row_delta, index_, tf.zeros(shape=(tf.shape(index_)[0],), dtype=tf.float32))

label_reshape=tf.reshape(label, [1,62,1])
gt_max_row_delta_reshape=tf.reshape(gt_max_row_delta_, [1,62,2])


###########################################################################################


gt_boxes_1st=RflxData_tf[kk][0]
gt_boxes_1st=tf.expand_dims(gt_boxes_1st,axis=0)
gt_labels_1st=1

iou_map_1st = bbox_utils.generate_iou_map(anchors, gt_boxes_1st)

# operate along axis 0
gt_argmax_col_1st = tf.argmax(iou_map_1st, axis=0, output_type=tf.int32)
gt_max_col_1st = tf.gather_nd(iou_map_1st, indices=tf.stack([gt_argmax_col_1st,tf.constant(np.arange(0,1))],axis=1))
gt_argmax_col_1st = tf.constant(np.where(iou_map_1st==gt_max_col_1st)[0])

# operate along axis 1
gt_argmax_row_1st = tf.argmax(iou_map_1st, axis=1, output_type=tf.int32)
gt_max_row_1st = tf.gather_nd(iou_map_1st, indices=tf.stack([tf.constant(np.arange(0,feature_map_shape)),gt_argmax_row_1st],axis=1))

# prepare label for training
label_1st=tf.zeros(shape=(feature_map_shape,), dtype=tf.int32)
label_1st=tf.where(gt_max_row_1st>pos_iou_threshold,2,label_1st)
label_1st=tf.where(gt_max_row_1st<neg_iou_threshold,1,label_1st)
label_1st=label_1st-1
label_1st=tf.tensor_scatter_nd_update(label_1st,tf.expand_dims(gt_argmax_col_1st,axis=1), tf.ones(shape=tf.shape(gt_argmax_col_1st), dtype=tf.int32))


n_pos_1st = pos_ratio_1st * n_sample_1st
pos_index_1st = np.where(label_1st == 1)[0]
if len(pos_index_1st) > n_pos_1st:
    disable_index_1st = np.random.choice(pos_index_1st, size=(len(pos_index_1st) - int(n_pos_1st)), replace=False)
    label_1st=tf.tensor_scatter_nd_update(label_1st, tf.expand_dims(disable_index_1st,axis=1), \
                                      -1*tf.ones(shape=np.shape(disable_index_1st), dtype=tf.int32))

n_neg_1st = n_sample_1st * (1.0 - pos_ratio_1st)
neg_index_1st = np.where(label_1st == 0)[0]
if len(neg_index_1st) > n_neg_1st:
    disable_index_1st = np.random.choice(neg_index_1st, size=(len(neg_index_1st) - int(n_neg_1st)), replace = False)
    label_1st=tf.tensor_scatter_nd_update(label_1st, tf.expand_dims(disable_index_1st,axis=1), \
                                      -1*tf.ones(shape=np.shape(disable_index_1st), dtype=tf.int32))
        
gt_max_row_box_1st = tf.gather_nd(gt_boxes_1st, indices=tf.expand_dims(gt_argmax_row_1st,axis=1))        
gt_max_row_delta_1st = bbox_utils.get_deltas_from_bboxes(anchors, gt_max_row_box_1st) 

index_1st=tf.where(tf.not_equal(label_1st, tf.constant(1, dtype=tf.int32)))
index_1st_=tf.concat([tf.concat([index_1st,tf.zeros_like(index_1st)],axis=1),tf.concat([index_1st,tf.ones_like(index_1st)],axis=1)],axis=0)
gt_max_row_delta_1st_ = tf.tensor_scatter_nd_update(gt_max_row_delta_1st, index_1st_, tf.zeros(shape=(tf.shape(index_1st_)[0],), dtype=tf.float32))

label_reshape_1st=tf.reshape(label_1st, [1,62,1])
gt_max_row_delta_reshape_1st=tf.reshape(gt_max_row_delta_1st_, [1,62,2])


##############################################################################################

gt_boxes_2nd=RflxData_tf[kk][batch_size-1]
gt_boxes_2nd=tf.expand_dims(gt_boxes_2nd,axis=0)
gt_labels_2nd=1

iou_map_2nd = bbox_utils.generate_iou_map(anchors, gt_boxes_2nd)

# operate along axis 0
gt_argmax_col_2nd = tf.argmax(iou_map_2nd, axis=0, output_type=tf.int32)
gt_max_col_2nd = tf.gather_nd(iou_map_2nd, indices=tf.stack([gt_argmax_col_2nd,tf.constant(np.arange(0,1))],axis=1))
gt_argmax_col_2nd = tf.constant(np.where(iou_map_2nd==gt_max_col_2nd)[0])

# operate along axis 1
gt_argmax_row_2nd = tf.argmax(iou_map_2nd, axis=1, output_type=tf.int32)
gt_max_row_2nd = tf.gather_nd(iou_map_2nd, indices=tf.stack([tf.constant(np.arange(0,feature_map_shape)),gt_argmax_row_2nd],axis=1))

# prepare label for training
label_2nd=tf.zeros(shape=(feature_map_shape,), dtype=tf.int32)
label_2nd=tf.where(gt_max_row_2nd>pos_iou_threshold,2,label_2nd)
label_2nd=tf.where(gt_max_row_2nd<neg_iou_threshold,1,label_2nd)
label_2nd=label_2nd-1
label_2nd=tf.tensor_scatter_nd_update(label_2nd,tf.expand_dims(gt_argmax_col_2nd,axis=1), tf.ones(shape=tf.shape(gt_argmax_col_2nd), dtype=tf.int32))


n_pos_2nd = pos_ratio_2nd * n_sample_2nd
pos_index_2nd = np.where(label_2nd == 1)[0]
if len(pos_index_2nd) > n_pos_2nd:
    disable_index_2nd = np.random.choice(pos_index_2nd, size=(len(pos_index_2nd) - int(n_pos_2nd)), replace=False)
    label_2nd=tf.tensor_scatter_nd_update(label_2nd, tf.expand_dims(disable_index_2nd,axis=1), \
                                      -1*tf.ones(shape=np.shape(disable_index_2nd), dtype=tf.int32))

n_neg_2nd = n_sample_2nd * (1.0 - pos_ratio_2nd)
neg_index_2nd = np.where(label_2nd == 0)[0]
if len(neg_index_2nd) > n_neg_2nd:
    disable_index_2nd = np.random.choice(neg_index_2nd, size=(len(neg_index_2nd) - int(n_neg_2nd)), replace = False)
    label_2nd=tf.tensor_scatter_nd_update(label_2nd, tf.expand_dims(disable_index_2nd,axis=1), \
                                      -1*tf.ones(shape=np.shape(disable_index_2nd), dtype=tf.int32))
        
gt_max_row_box_2nd = tf.gather_nd(gt_boxes_2nd, indices=tf.expand_dims(gt_argmax_row_2nd,axis=1))        
gt_max_row_delta_2nd = bbox_utils.get_deltas_from_bboxes(anchors, gt_max_row_box_2nd) 

index_2nd=tf.where(tf.not_equal(label_2nd, tf.constant(1, dtype=tf.int32)))
index_2nd_=tf.concat([tf.concat([index_2nd,tf.zeros_like(index_2nd)],axis=1),tf.concat([index_2nd,tf.ones_like(index_2nd)],axis=1)],axis=0)
gt_max_row_delta_2nd_ = tf.tensor_scatter_nd_update(gt_max_row_delta_2nd, index_2nd_, tf.zeros(shape=(tf.shape(index_2nd_)[0],), dtype=tf.float32))

label_reshape_2nd=tf.reshape(label_2nd, [1,62,1])
gt_max_row_delta_reshape_2nd=tf.reshape(gt_max_row_delta_2nd_, [1,62,2])

