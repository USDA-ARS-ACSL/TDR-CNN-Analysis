You will need to train the VGG16_TDR here, or you can use "myVGG1D_H5" as the model
1. "CNN_TDR_1D.py" is the main code
2. At the beginning of "CNN_TDR_1D.py", you see "WaveData=pd.read_csv('Wave_Data.csv', header=None).astype(np.float32)" and "WaveCatg=pd.read_csv('Wave_Catg.csv', header=None).astype(np.uint8)". That means you will need to collect all the waveform data from 002 and name it as "Wave_Data.csv" and collect all the waveform_catg data from 002 and name it as"Wave_Catg.csv"
3. "Wave_Data.csv" and "Wave_Catg.csv" will be the training data
4. The model will be saved in a H5 file, i.e., "myVGG1D_H5". That is the VGG16-TDR
5. Hereafter, other codes, such as "CNNplot.py", will not be in the mainstream of the model, but are auxillary codes.