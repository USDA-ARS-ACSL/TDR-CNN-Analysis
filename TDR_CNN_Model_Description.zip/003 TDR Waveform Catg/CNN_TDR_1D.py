import numpy as np
import pandas as pd
import tensorflow as tf
import sklearn as skl

WaveData=pd.read_csv('Wave_Data.csv', header=None).astype(np.float32)
WaveCatg=pd.read_csv('Wave_Catg.csv', header=None).astype(np.uint8)

WaveData=WaveData.to_numpy(copy=True)
WaveCatg=WaveCatg.to_numpy(copy=True)

DataLength, WaveLength=WaveData.shape
WaveData=WaveData.reshape((DataLength,WaveLength))
WaveData=(WaveData+1)/2.5
WaveCatg=WaveCatg.reshape((-1))-1

WaveData, WaveCatg=skl.utils.shuffle(WaveData, WaveCatg, random_state=0)

model = tf.keras.Sequential([
    tf.keras.layers.InputLayer(input_shape=(WaveLength,1)),
    tf.keras.layers.Conv1D(filters=4, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=8, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=16, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=32, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(16, activation='relu'),
    tf.keras.layers.Dense(4,activation='softmax')
    ])

lr = tf.keras.optimizers.schedules.PiecewiseConstantDecay([100,150],[1e-3,5e-4,1e-4])
                          
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])
model.summary()

model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(filepath='weights.{epoch:02d}.h5', monitor='loss', mode='min', save_best_only=True)
history=model.fit(WaveData, WaveCatg, epochs=150, callbacks=[model_checkpoint_callback], validation_split=0.1)
history=model.fit(WaveData, WaveCatg, epochs=200, callbacks=[model_checkpoint_callback], validation_split=0.0)


tf.keras.models.save_model(model,'myVGG1D_H5',save_format='h5')


import pickle
with open('D:/PDE_ANN/Waveform_Catg/TrainHistory_CNN_TDR_1D', 'wb') as file_pi:
    pickle.dump(history.history, file_pi)
    file_pi.close()
    
model_reload=tf.keras.models.load_model('myVGG1D_H5')
pred=model_reload.predict(WaveData[101:111,])
pred_catg=np.argmax(pred,axis=1)+1
print(pred_catg)

with open('D:/PDE_ANN/Waveform_Catg/TrainHistory_CNN_TDR_1D', 'rb') as file_pi:
    history_reload=pickle.load(file_pi)
    file_pi.close()
    


