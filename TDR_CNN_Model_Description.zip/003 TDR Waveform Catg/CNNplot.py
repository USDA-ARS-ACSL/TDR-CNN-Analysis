# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 16:23:06 2022

@author: Zhuangji.Wang
"""

import pickle
import numpy as np
with open('D:/PDE_ANN/Waveform_Catg/TrainHistory_CNN_TDR_1D', 'rb') as file_pi:
    history_reload=pickle.load(file_pi)
    file_pi.close()
    
Loss=history_reload['loss']
Val_Loss=history_reload['val_loss']
Accur=history_reload['accuracy']
Val_Accur=history_reload['val_accuracy']

Results=np.array((Loss,Val_Loss,Accur,Val_Accur))

np.savetxt("Error.csv", Results, delimiter=",")


import numpy as np

x=np.arange(len(Loss))


import matplotlib.pyplot as plt

fig, host = plt.subplots(figsize=(10,4))

#plt.rcParams['font.size'] = '20'
plt.rcParams['font.family'] = 'Times New Roman'

ax_r = host.twinx()

host.plot(x, Loss,'g-')
host.plot(x, Val_Loss,'g-.')

ax_r.plot(x, Accur,'b-')
ax_r.plot(x, Val_Accur,'b-.')

host.set_yscale('log')
ax_r.set_yscale('linear')

#host.set_xlabel("Training Epochs")
host.set_ylabel("Cross-entrop Loss")
ax_r.set_ylabel("Accuracy")


host.yaxis.label.set_color('g')
ax_r.yaxis.label.set_color('b')

host.spines["left"].set_edgecolor('g')
ax_r.spines["right"].set_edgecolor('b')

host.tick_params(axis='y', colors='g')
ax_r.tick_params(axis='y', colors='b')

plt.show()

#fig.savefig('Error_plot.png', dpi=600)
