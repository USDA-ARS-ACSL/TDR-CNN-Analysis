In this folder, we will present the TDR-CNN structures. We will lead the readers through the model step by step, and provide the readers a chance to generate their own data and train their own model, based on the TDR-CNN architecture. The TDR-CNN architecture is of open source. Therefore, anyone can use, refer or improve it.

Subfolders:
001, if you do not know TDR waveforms, we can generate some examples.
002, we provide a TDR waveform generator, you will see how to simulate TDR-waveforms using the Transmission Line equation with finite difference method.
003, VGG16-TDR module
004, RPN-TDR module (we present three RPNs for 1 the first reflection position, 2 the second reflection position and 3 the third reflection position)
005, REG-TDR module
006, Application example

Remarks
1. The working path within the code (i.e., the address of your folder) will need to be changed when you run the code.
2. In each subfolders, always see the readme file first.