This file is divided into 2 parts

****** Part 1 training the REG_TDR ************************************
1. Prepare the training data
   Use the "SectionOne_DataPrepare.m", you will need to copy 
   XXXsec_WaveForm.csv; XXXsec_Reflx.csv; XXXsec_Er.xlsx from 002, XXX=1,2,3,4
2. "REG_TDR" is the maintraining code and it will generate "myREGH5.h5" as the REG_TDR network

****** Part 2 combine all the module to establish the TDR_CNN ************************************
1. The main code to complete that is "TDR_Data_Interp_Framework.py"
2. All the H5 files, i.e., VGG16_TDR, RPN_TDR, and REG_TDR, should be copied into this folder and "TDR_Data_Interp_Framework.py" will need to read all the modules.
