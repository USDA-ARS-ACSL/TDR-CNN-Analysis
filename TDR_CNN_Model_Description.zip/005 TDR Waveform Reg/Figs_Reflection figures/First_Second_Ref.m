clear all
close all
clc

DataRef1=xlsread('Group1.csv');
DataRef2=xlsread('Group2.csv');
DataRef3=xlsread('Group3.csv');
DataRef4=xlsread('Group4.csv');

SecondRef2=xlsread('Group2_2nd.csv');
SecondRef3=xlsread('Group3_2nd.csv');
SecondRef4=xlsread('Group4_2nd.csv');

figure(1)

hold on
scatter(DataRef1(:,1),DataRef1(:,3),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)
scatter(DataRef1(:,2),DataRef1(:,4),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)

%plot([-100,1000],[0,1100],'k--')
%plot([100,1100],[0,1000],'k--')

fill([-100,1100,-100],[0,1200,1200],'c','FaceAlpha',0.2,'EdgeColor','none')
fill([100,1100,1100],[0,0,1000],'c','FaceAlpha',0.2,'EdgeColor','none')

box on
%axis equal
axis([-100,900,200,1200])
set(gca,'FontName','Times New Roman','FontSize',20) 

figure(2)

hold on
scatter(DataRef2(:,1),DataRef2(:,4),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)
scatter(DataRef2(:,2),DataRef2(:,5),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#77AC30','MarkerFaceAlpha',0.05)
scatter(DataRef2(:,3),DataRef2(:,6),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)

%plot([-100,1000],[0,1100],'k--')
%plot([100,1100],[0,1000],'k--')

fill([-100,1100,-100],[0,1200,1200],'c','FaceAlpha',0.2,'EdgeColor','none')
fill([100,1100,1100],[0,0,1000],'c','FaceAlpha',0.2,'EdgeColor','none')

box on
%axis equal
axis([-100,900,200,1200])
set(gca,'FontName','Times New Roman','FontSize',20) 

figure(3)

hold on
scatter(DataRef3(:,1),DataRef3(:,5),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)
scatter(DataRef3(:,2),DataRef3(:,6),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#77AC30','MarkerFaceAlpha',0.05)
scatter(DataRef3(:,3),DataRef3(:,7),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#0072BD','MarkerFaceAlpha',0.05)
scatter(DataRef3(:,4),DataRef3(:,8),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)

%plot([-100,1000],[0,1100],'k--')
%plot([100,1100],[0,1000],'k--')

fill([-100,1100,-100],[0,1200,1200],'c','FaceAlpha',0.2,'EdgeColor','none')
fill([100,1100,1100],[0,0,1000],'c','FaceAlpha',0.2,'EdgeColor','none')

box on
%axis equal
axis([-100,900,200,1200])
set(gca,'FontName','Times New Roman','FontSize',20) 

figure(4)

hold on
scatter(DataRef4(:,1),DataRef4(:,6),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)
scatter(DataRef4(:,2),DataRef4(:,7),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#77AC30','MarkerFaceAlpha',0.05)
scatter(DataRef4(:,3),DataRef4(:,8),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#0072BD','MarkerFaceAlpha',0.05)
scatter(DataRef4(:,4),DataRef4(:,9),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#D95319','MarkerFaceAlpha',0.05)
scatter(DataRef4(:,5),DataRef4(:,10),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)

%plot([-100,1000],[0,1100],'k--')
%plot([100,1100],[0,1000],'k--')

fill([-100,1100,-100],[0,1200,1200],'c','FaceAlpha',0.2,'EdgeColor','none')
fill([100,1100,1100],[0,0,1000],'c','FaceAlpha',0.2,'EdgeColor','none')

box on
%axis equal
axis([-100,900,200,1200])
set(gca,'FontName','Times New Roman','FontSize',20) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(6)

hold on
scatter(SecondRef2(:,1),SecondRef2(:,2),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)

fill([-100,900,-100],[0,1000,1000],'y','FaceAlpha',0.2,'EdgeColor','none')
fill([100,1100,1100],[0,0,1000],'y','FaceAlpha',0.2,'EdgeColor','none')

box on
axis equal
axis([200,1000,200,1000])
set(gca,'FontName','Times New Roman','FontSize',24) 

figure(7)

hold on
scatter(SecondRef3(:,1),SecondRef3(:,2),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)

fill([-100,900,-100],[0,1000,1000],'y','FaceAlpha',0.2,'EdgeColor','none')
fill([100,1100,1100],[0,0,1000],'y','FaceAlpha',0.2,'EdgeColor','none')

box on
axis equal
axis([200,1000,200,1000])
set(gca,'FontName','Times New Roman','FontSize',24) 


figure(8)

hold on
scatter(SecondRef4(:,1),SecondRef4(:,2),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)

fill([-100,900,-100],[0,1000,1000],'y','FaceAlpha',0.2,'EdgeColor','none')
fill([100,1100,1100],[0,0,1000],'y','FaceAlpha',0.2,'EdgeColor','none')

box on
axis equal
axis([200,1000,200,1000])
set(gca,'FontName','Times New Roman','FontSize',24) 


mean(abs(rmmissing(DataRef1(:,1)-DataRef1(:,3))))
mean(abs(rmmissing(DataRef1(:,2)-DataRef1(:,4))))
mean(abs(rmmissing(DataRef2(:,1)-DataRef2(:,4))))
mean(abs(rmmissing(DataRef2(:,2)-DataRef2(:,5))))
mean(abs(rmmissing(DataRef2(:,3)-DataRef2(:,6))))
mean(abs(rmmissing(DataRef3(:,1)-DataRef3(:,5))))
mean(abs(rmmissing(DataRef3(:,2)-DataRef3(:,6))))
mean(abs(rmmissing(DataRef3(:,3)-DataRef3(:,7))))
mean(abs(rmmissing(DataRef3(:,4)-DataRef3(:,8))))
mean(abs(rmmissing(DataRef4(:,1)-DataRef4(:,6))))
mean(abs(rmmissing(DataRef4(:,2)-DataRef4(:,7))))
mean(abs(rmmissing(DataRef4(:,3)-DataRef4(:,8))))
mean(abs(rmmissing(DataRef4(:,4)-DataRef4(:,9))))
mean(abs(rmmissing(DataRef4(:,5)-DataRef4(:,10))))