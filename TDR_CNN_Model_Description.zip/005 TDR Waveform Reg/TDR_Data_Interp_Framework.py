# this is the code start with read the waveforms

import sys
import numpy as np
import pandas as pd
import tensorflow as tf
# import sklearn as skl

np.set_printoptions(threshold=sys.maxsize)


###############################################################################
# Prepare necessary dataset for TDR RPN training

WaveData_1sec=pd.read_csv('1sec_WaveForm.csv', header=None).astype(np.float32)
WaveData_1sec=WaveData_1sec.to_numpy(copy=True)
WaveData_1sec=(WaveData_1sec+1)/2.5
DataLength_1sec, WaveWidth_1sec=WaveData_1sec.shape
WaveData_1sec=WaveData_1sec.reshape((DataLength_1sec, WaveWidth_1sec))

WaveData_2sec=pd.read_csv('2sec_WaveForm.csv', header=None).astype(np.float32)
WaveData_2sec=WaveData_2sec.to_numpy(copy=True)
WaveData_2sec=(WaveData_2sec+1)/2.5
DataLength_2sec, WaveWidth_2sec=WaveData_2sec.shape
WaveData_2sec=WaveData_2sec.reshape((DataLength_2sec, WaveWidth_2sec))

WaveData_3sec=pd.read_csv('3sec_WaveForm.csv', header=None).astype(np.float32)
WaveData_3sec=WaveData_3sec.to_numpy(copy=True)
WaveData_3sec=(WaveData_3sec+1)/2.5
DataLength_3sec, WaveWidth_3sec=WaveData_3sec.shape
WaveData_3sec=WaveData_3sec.reshape((DataLength_3sec, WaveWidth_3sec))

WaveData_4sec=pd.read_csv('4sec_WaveForm.csv', header=None).astype(np.float32)
WaveData_4sec=WaveData_4sec.to_numpy(copy=True)
WaveData_4sec=(WaveData_4sec+1)/2.5
DataLength_4sec, WaveWidth_4sec=WaveData_4sec.shape
WaveData_4sec=WaveData_4sec.reshape((DataLength_4sec, WaveWidth_4sec))

WaveData_tf=[]

for kk in np.arange(DataLength_1sec):
    wf=tf.convert_to_tensor(WaveData_1sec[kk].reshape((WaveWidth_1sec,1)))
    WaveData_tf.append(wf)   
    
for kk in np.arange(DataLength_2sec):
    wf=tf.convert_to_tensor(WaveData_2sec[kk].reshape((WaveWidth_2sec,1)))
    WaveData_tf.append(wf) 

for kk in np.arange(DataLength_3sec):
    wf=tf.convert_to_tensor(WaveData_3sec[kk].reshape((WaveWidth_3sec,1)))
    WaveData_tf.append(wf)        
    
for kk in np.arange(DataLength_4sec):
    wf=tf.convert_to_tensor(WaveData_4sec[kk].reshape((WaveWidth_4sec,1)))
    WaveData_tf.append(wf)  
    
DataLength_tf=DataLength_1sec+DataLength_2sec+DataLength_3sec+DataLength_4sec
WaveWidth_tf=WaveWidth_1sec
WaveData_tf=np.asarray(WaveData_tf)

del WaveData_1sec, WaveData_2sec, WaveData_3sec, WaveData_4sec

# Finish prepare the dataset

###############################################################################
# preload the TDR_CNN model 
model_pretrain=tf.keras.models.load_model('myVGG1D_H5')
Layer_Conv_1_Kernel=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[0])
Layer_Conv_1_Bias=tf.keras.initializers.constant(model_pretrain.layers[0].get_weights()[1])
Layer_Conv_2_Kernel=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[0])
Layer_Conv_2_Bias=tf.keras.initializers.constant(model_pretrain.layers[2].get_weights()[1])
Layer_Conv_3_Kernel=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[0])
Layer_Conv_3_Bias=tf.keras.initializers.constant(model_pretrain.layers[4].get_weights()[1])
Layer_Conv_4_Kernel=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[0])
Layer_Conv_4_Bias=tf.keras.initializers.constant(model_pretrain.layers[6].get_weights()[1])

base_model=tf.keras.Sequential([
    tf.keras.layers.InputLayer(input_shape=(WaveWidth_tf,1)),
    tf.keras.layers.Conv1D(filters=4, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_1_Kernel, bias_initializer=Layer_Conv_1_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=8, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_2_Kernel, bias_initializer=Layer_Conv_2_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=16, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_3_Kernel, bias_initializer=Layer_Conv_3_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=32, kernel_size=3, strides=1, padding='same', activation='relu', kernel_initializer=Layer_Conv_4_Kernel, bias_initializer=Layer_Conv_4_Bias),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
])

for layer in base_model.layers:
    layer.trainable=False

# the waveform feature has dimension 40000(datapoint)*62/50(spatial point)*16/24/32(features)
WaveFeature_tf=base_model.predict(WaveData_tf)

###############################################################################
# prepare the box dataset 
import bbox_utils, train_utils

hyper_params=train_utils.get_hyper_params()
# We add 1 class for background
hyper_params["total_labels"]=3+1 

    
# create the anchor boxes    
anchors = bbox_utils.generate_anchors(hyper_params)    

feature_map_shape = hyper_params["feature_map_shape"]
anchor_count = hyper_params["anchor_count"]
total_pos_bboxes = hyper_params["total_pos_bboxes"]
total_neg_bboxes = hyper_params["total_neg_bboxes"]
variances = hyper_params["variances"]

###############################################################################

rpn_model=tf.keras.models.load_model('myRPN1D_H5',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})  
rpn_model_1st=tf.keras.models.load_model('myRPN1D_H5_1st',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})   
rpn_model_2nd=tf.keras.models.load_model('myRPN1D_H5_2nd',custom_objects={'reg_loss': train_utils.reg_loss, 'cls_loss': train_utils.cls_loss})   

WaveRPN_tf=rpn_model.predict(WaveFeature_tf)
rpn_reg_tf, rpn_cls_tf=WaveRPN_tf

WaveRPN_tf_1st=rpn_model_1st.predict(WaveFeature_tf)
rpn_reg_tf_1st, rpn_cls_tf_1st=WaveRPN_tf_1st

WaveRPN_tf_2nd=rpn_model_2nd.predict(WaveFeature_tf)
rpn_reg_tf_2nd, rpn_cls_tf_2nd=WaveRPN_tf_2nd

import wave_utils
###############################################################################
# first detect the 1st reflection position

rpn_bbox_1st = wave_utils.get_proposal_bboxes_1st(DataLength_tf, rpn_reg_tf_1st, rpn_cls_tf_1st, anchors)
rflx_res_1st = wave_utils.get_rflx_position_1st(DataLength_tf, rpn_bbox_1st, WaveData_tf)

###############################################################################
# second detect the 2nd reflection position

rpn_bbox_2nd = wave_utils.get_proposal_bboxes_2nd(DataLength_tf, rpn_reg_tf_2nd, rpn_cls_tf_2nd, anchors)
rflx_res_2nd = wave_utils.get_rflx_position_2nd(DataLength_tf, rpn_bbox_2nd, WaveData_tf)

##############################################################################
# third detect internal reflection positions
# using the first and second refection position as the pre-knowledge

rpn_bbox = wave_utils.get_proposal_bboxes(DataLength_tf, rpn_reg_tf, rpn_cls_tf, anchors)
rflx_res, rflx_num, rflx_res_2nd = wave_utils.get_rflx_position(DataLength_tf, rpn_bbox, WaveData_tf, rflx_res_1st, rflx_res_2nd)

np.savetxt('rflx_num_1st.csv', rflx_res_1st, delimiter=',')
np.savetxt('rflx_num_2nd.csv', rflx_res_2nd, delimiter=',')


np.savetxt('rflx_num_2nd_01.csv', rflx_res_2nd[0000:10000], delimiter=',')
np.savetxt('rflx_num_2nd_02.csv', rflx_res_2nd[10000:20000], delimiter=',')
np.savetxt('rflx_num_2nd_03.csv', rflx_res_2nd[20000:30000], delimiter=',')
np.savetxt('rflx_num_2nd_04.csv', rflx_res_2nd[30000:40000], delimiter=',')



np.savetxt('rflx_num_01.csv', rflx_num[0000:10000], delimiter=',')
np.savetxt('rflx_num_02.csv', rflx_num[10000:20000], delimiter=',')
np.savetxt('rflx_num_03.csv', rflx_num[20000:30000], delimiter=',')
np.savetxt('rflx_num_04.csv', rflx_num[30000:40000], delimiter=',')

import csv

with open('rflx_res_01.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[0000:10000])
    
with open('rflx_res_02.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[10000:20000])
    
with open('rflx_res_03.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[20000:30000])
    
with open('rflx_res_04.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[30000:40000])

###############################################################################
## determine the relative permittivity

Feeding_range=50.0
Er_small_thre=5.0
Er_res=[]
model_reg=tf.keras.models.load_model('myREGH5.h5')

for kk in np.arange(DataLength_tf):
        
    rflx_num_each=rflx_num[kk]
    rflx_res_each=rflx_res[kk]
    Wave_each=WaveData_tf[kk]
    Wave_Feeding=[]
    
    # for each waveform, transform each segment into the standard format, 50*1 length
    for tt in np.arange(1,rflx_num_each,dtype=np.int32):
        
        pt_1=np.ceil(rflx_res_each[tt-1])
        pt_2=np.ceil(rflx_res_each[tt])
        pt_1_int=pt_1.astype(np.int32)
        pt_2_int=pt_2.astype(np.int32)
        
        Wave_seg=np.array(Wave_each[pt_1_int:pt_2_int,]).reshape((-1))
        x_Wave_seg=(np.arange(pt_1,pt_2).astype(np.float32)-pt_1)/(pt_2-pt_1)*Feeding_range
        x_interp=np.arange(0,Feeding_range).astype(np.float32)
        Wave_interp=np.interp(x_interp,x_Wave_seg,Wave_seg)
        
        Wave_Feeding.append(Wave_interp)
        
    # for each waveform, make prediction with the regression network   
    Wave_Feeding=np.array(Wave_Feeding)
    Wave_Feeding=np.expand_dims(Wave_Feeding,2)
    Er_res_each=model_reg.predict(Wave_Feeding)
    
    # check if the Er values is smaller than 5, then remove that section since they are subjected to multiple reflection
    
    remove=0
    for tt in np.arange(rflx_num_each-1,0,-1,dtype=np.int32):
        
        if Er_res_each[tt-1]<5:
            
           remove=remove-1
           
    
    if remove<0:
        rflx_res_2nd[kk]=rflx_res[kk][-1]
        Er_res_each=Er_res_each[:remove]
        rflx_res[kk]=rflx_res[kk][:remove]
        rflx_num[kk]=rflx_num_each+remove
    
    Er_res_each.reshape((-1))
    Er_res.append(Er_res_each)
        


np.savetxt('rflx_num_2nd_01_rev.csv', rflx_res_2nd[0000:10000], delimiter=',')
np.savetxt('rflx_num_2nd_02_rev.csv', rflx_res_2nd[10000:20000], delimiter=',')
np.savetxt('rflx_num_2nd_03_rev.csv', rflx_res_2nd[20000:30000], delimiter=',')
np.savetxt('rflx_num_2nd_04_rev.csv', rflx_res_2nd[30000:40000], delimiter=',')



np.savetxt('rflx_num_01_rev.csv', rflx_num[0000:10000], delimiter=',')
np.savetxt('rflx_num_02_rev.csv', rflx_num[10000:20000], delimiter=',')
np.savetxt('rflx_num_03_rev.csv', rflx_num[20000:30000], delimiter=',')
np.savetxt('rflx_num_04_rev.csv', rflx_num[30000:40000], delimiter=',')


with open('rflx_res_01_rev.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[0000:10000])
    
with open('rflx_res_02_rev.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[10000:20000])
    
with open('rflx_res_03_rev.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[20000:30000])
    
with open('rflx_res_04_rev.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(rflx_res[30000:40000])
    
           
with open('Er_res_01_rev.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(Er_res[0000:10000])
    
with open('Er_res_02_rev.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(Er_res[10000:20000])
    
with open('Er_res_03_rev.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(Er_res[20000:30000])
    
with open('Er_res_04_rev.csv','w', newline='') as f:
    writer=csv.writer(f)
    writer.writerows(Er_res[30000:40000])
    
    
    
    

    
    
    