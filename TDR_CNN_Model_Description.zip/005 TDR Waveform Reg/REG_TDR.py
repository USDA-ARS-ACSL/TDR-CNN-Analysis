# -*- coding: utf-8 -*-
"""
Created on Thu Jul 14 17:12:32 2022

@author: Zhuangji.Wang
"""

import numpy as np
import pandas as pd
import tensorflow as tf
import sklearn as skl

WaveData=pd.read_csv('Training_Wave.csv', header=None).astype(np.float32)
WaveEr=pd.read_csv('Training_Er.csv', header=None).astype(np.float32)

WaveData=WaveData.to_numpy(copy=True)
WaveEr=WaveEr.to_numpy(copy=True)

DataLength, WaveLength=WaveData.shape
WaveData=WaveData.reshape((DataLength,WaveLength))
WaveData=(WaveData+1)/2.5
WaveEr=WaveEr.reshape((-1))

WaveData, WaveEr=skl.utils.shuffle(WaveData, WaveEr, random_state=0)

#WaveEr=tf.constant(WaveEr,dtype=tf.float32)

model_reg = tf.keras.Sequential([
    tf.keras.layers.InputLayer(input_shape=(WaveLength,1)),
    tf.keras.layers.Conv1D(filters=4, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=8, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=16, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Conv1D(filters=32, kernel_size=3, strides=1, padding='same', activation='relu'),
    tf.keras.layers.MaxPool1D(pool_size=2, strides=2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(32, activation='relu'),
    tf.keras.layers.Dense(1, activation='linear')
    ])

lr = tf.keras.optimizers.schedules.PiecewiseConstantDecay([1000,1500],[1e-2,1e-3,1e-4])
                          
model_reg.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
              loss=tf.keras.losses.Huber())
model_reg.summary()

history_reg=model_reg.fit(WaveData, WaveEr, epochs=2000)

# save model and history
tf.keras.models.save_model(model_reg,'myREGH5.h5',save_format='h5')

import pickle
with open('D:/PDE_ANN/Waveform_Reg/TrainHistory_model_reg', 'wb') as file_pi:
    pickle.dump(history_reg.history, file_pi)
    file_pi.close()    

# reload model if I have a good one
model_reg=tf.keras.models.load_model('myREGH5.h5')  

WaveData=pd.read_csv('Training_Wave.csv', header=None).astype(np.float32)
WaveData=WaveData.to_numpy(copy=True)
WaveData=(WaveData+1)/2.5

ErPredict=model_reg.predict(WaveData)

np.savetxt('tdr_reg_sample.csv', ErPredict, delimiter=',')
