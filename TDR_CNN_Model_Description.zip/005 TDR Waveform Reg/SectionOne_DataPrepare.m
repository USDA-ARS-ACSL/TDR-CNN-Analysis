clear all
close all
clc

Wave_1sec=xlsread('1sec_WaveForm.csv');
Rflx_1sec=xlsread('1sec_Reflx.csv');

Rflx_1sec=ceil(Rflx_1sec);

Target_L=50;
Xq=1:Target_L;
Data_1sec=zeros(10000,Target_L);

for kk=1:10000
    
    range=Rflx_1sec(kk,1):Rflx_1sec(kk,2);
    data=Wave_1sec(kk,range);
    range=(range-range(1))./(Rflx_1sec(kk,2)-Rflx_1sec(kk,1)).*Target_L;
    Data_1sec(kk,:)=interp1(range,data,Xq);
    
end

Wave_2sec=xlsread('2sec_WaveForm.csv');
Rflx_2sec=xlsread('2sec_Reflx.csv');

Rflx_2sec=ceil(Rflx_2sec);

Xq=1:Target_L;
Data_2sec=zeros(20000,Target_L);

for kk=1:10000
    
    range=Rflx_2sec(kk,1):Rflx_2sec(kk,2);
    data=Wave_2sec(kk,range);
    range=(range-range(1))./(Rflx_2sec(kk,2)-Rflx_2sec(kk,1)).*Target_L;
    Data_2sec(2*kk-1,:)=interp1(range,data,Xq);
    
    range=Rflx_2sec(kk,2):Rflx_2sec(kk,3);
    data=Wave_2sec(kk,range);
    range=(range-range(1))./(Rflx_2sec(kk,3)-Rflx_2sec(kk,2)).*Target_L;
    Data_2sec(2*kk,:)=interp1(range,data,Xq);
    
end

Wave_3sec=xlsread('3sec_WaveForm.csv');
Rflx_3sec=xlsread('3sec_Reflx.csv');

Rflx_3sec=ceil(Rflx_3sec);

Xq=1:Target_L;
Data_3sec=zeros(30000,Target_L);

for kk=1:10000
    
    range=Rflx_3sec(kk,1):Rflx_3sec(kk,2);
    data=Wave_3sec(kk,range);
    range=(range-range(1))./(Rflx_3sec(kk,2)-Rflx_3sec(kk,1)).*Target_L;
    Data_3sec(3*kk-2,:)=interp1(range,data,Xq);
    
    range=Rflx_3sec(kk,2):Rflx_3sec(kk,3);
    data=Wave_3sec(kk,range);
    range=(range-range(1))./(Rflx_3sec(kk,3)-Rflx_3sec(kk,2)).*Target_L;
    Data_3sec(3*kk-1,:)=interp1(range,data,Xq);
    
    range=Rflx_3sec(kk,3):Rflx_3sec(kk,4);
    data=Wave_3sec(kk,range);
    range=(range-range(1))./(Rflx_3sec(kk,4)-Rflx_3sec(kk,3)).*Target_L;
    Data_3sec(3*kk,:)=interp1(range,data,Xq);
    
end

Wave_4sec=xlsread('4sec_WaveForm.csv');
Rflx_4sec=xlsread('4sec_Reflx.csv');

Rflx_4sec=ceil(Rflx_4sec);

Xq=1:Target_L;
Data_4sec=zeros(40000,Target_L);

for kk=1:10000
    
    range=Rflx_4sec(kk,1):Rflx_4sec(kk,2);
    data=Wave_4sec(kk,range);
    range=(range-range(1))./(Rflx_4sec(kk,2)-Rflx_4sec(kk,1)).*Target_L;
    Data_4sec(4*kk-3,:)=interp1(range,data,Xq);
    
    range=Rflx_4sec(kk,2):Rflx_4sec(kk,3);
    data=Wave_4sec(kk,range);
    range=(range-range(1))./(Rflx_4sec(kk,3)-Rflx_4sec(kk,2)).*Target_L;
    Data_4sec(4*kk-2,:)=interp1(range,data,Xq);
    
    range=Rflx_4sec(kk,3):Rflx_4sec(kk,4);
    data=Wave_4sec(kk,range);
    range=(range-range(1))./(Rflx_4sec(kk,4)-Rflx_4sec(kk,3)).*Target_L;
    Data_4sec(4*kk-1,:)=interp1(range,data,Xq);
    
    range=Rflx_4sec(kk,4):Rflx_4sec(kk,5);
    data=Wave_4sec(kk,range);
    range=(range-range(1))./(Rflx_4sec(kk,5)-Rflx_4sec(kk,4)).*Target_L;
    Data_4sec(4*kk,:)=interp1(range,data,Xq);
    
end

Data=[Data_1sec;Data_2sec;Data_3sec;Data_4sec];
xlswrite('Training_Wave.xlsx',Data);


Er_1sec=xlsread('1sec_Er.xlsx');
Er_2sec=xlsread('2sec_Er.xlsx');
Er_3sec=xlsread('3sec_Er.xlsx');
Er_4sec=xlsread('4sec_Er.xlsx');

Er_2sec=Er_2sec';
Er_2sec=reshape(Er_2sec,[20000,1]);

Er_3sec=Er_3sec';
Er_3sec=reshape(Er_3sec,[30000,1]);

Er_4sec=Er_4sec';
Er_4sec=reshape(Er_4sec,[40000,1]);

Er=[Er_1sec(:,1); Er_2sec(:,1); Er_3sec(:,1); Er_4sec(:,1)];
xlswrite('Training_Er.xlsx',Er);
