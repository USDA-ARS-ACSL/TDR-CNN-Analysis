clear all
close all
clc

DataEr1=xlsread('Group1.csv');
DataEr2=xlsread('Group2.csv');
DataEr3=xlsread('Group3.csv');
DataEr4=xlsread('Group4.csv');


figure(1)

hold on
scatter(DataEr1(:,1),DataEr1(:,2),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)

box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% figure(21)
% 
% hold on
% scatter(DataEr2(:,1),DataEr2(:,3),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)
% 
% figure(22)
% 
% hold on
% scatter(DataEr2(:,2),DataEr2(:,4),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)

figure(2)

pos1=[0.13,0.11,0.39,0.82];
pos2=[0.5201,0.11,0.39,0.82];

subplot('Position',pos1)
hold on
scatter(DataEr2(:,1),DataEr2(:,3),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)

box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)

subplot('Position',pos2)
hold on
scatter(DataEr2(:,2),DataEr2(:,4),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)

set(gca, 'yticklabel', [])

box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% figure(31)
% 
% hold on
% scatter(DataEr3(:,1),DataEr3(:,4),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)
% 
% figure(32)
% hold on
% scatter(DataEr3(:,2),DataEr3(:,5),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)
% 
% 
% figure(33)
% hold on
% scatter(DataEr3(:,3),DataEr3(:,6),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','b','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)

figure(3)
pos1=[0.13,0.11,0.26,0.82];
pos2=[0.3901,0.11,0.26,0.82];
pos3=[0.6502,0.11,0.26,0.82];

subplot('Position',pos1)

hold on
scatter(DataEr3(:,1),DataEr3(:,4),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)

box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)

subplot('Position',pos2)
hold on
scatter(DataEr3(:,2),DataEr3(:,5),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)

set(gca, 'yticklabel', [])
box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)


subplot('Position',pos3)
hold on
scatter(DataEr3(:,3),DataEr3(:,6),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)

set(gca, 'yticklabel', [])
box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)


% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% figure(41)
% 
% hold on
% scatter(DataEr4(:,1),DataEr4(:,5),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)
% 
% figure(42)
% 
% hold on
% scatter(DataEr4(:,2),DataEr4(:,6),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#A2142F','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)
% 
% figure(43)
% 
% hold on
% scatter(DataEr4(:,3),DataEr4(:,7),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','b','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)
% 
% figure(44)
% 
% hold on
% scatter(DataEr4(:,4),DataEr4(:,8),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','#77AC30','MarkerFaceAlpha',0.05)
% 
% fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')
% box on
% axis([0,100,0,100])
% set(gca,'FontName','Times New Roman','FontSize',20)

figure(4)

pos1=[0.13,0.5201,0.39,0.41];
pos2=[0.5201,0.5201,0.39,0.41];
pos3=[0.13,0.11,0.39,0.41];
pos4=[0.5201,0.11,0.39,0.41];

subplot('Position',pos1)

hold on
scatter(DataEr4(:,1),DataEr4(:,5),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)

set(gca, 'xticklabel', [])
box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)

subplot('Position',pos2)

hold on
scatter(DataEr4(:,2),DataEr4(:,6),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)

box on
set(gca, 'xticklabel', [])
set(gca, 'yticklabel', [])
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)

subplot('Position',pos3)

hold on
scatter(DataEr4(:,3),DataEr4(:,7),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)
box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)

subplot('Position',pos4)

hold on
scatter(DataEr4(:,4),DataEr4(:,8),'o','SizeData',100,'MarkerEdgeColor','None','MarkerFaceColor','k','MarkerFaceAlpha',0.05)

%fill([-10,90,-10],[0,100,100],'c','FaceAlpha',0.2,'EdgeColor','none')
%fill([10,110,110],[0,0,100],'c','FaceAlpha',0.2,'EdgeColor','none')

plot([-10,90],[0,100],'r--','linewidth',1.5)
plot([10,110],[0,100],'r--','linewidth',1.5)
set(gca, 'yticklabel', [])
box on
axis([0,100,0,100])
set(gca,'FontName','Times New Roman','FontSize',20)

mean(abs(rmmissing(DataEr1(:,1)-DataEr1(:,2))))
mean(abs(rmmissing(DataEr2(:,1)-DataEr2(:,3))))
mean(abs(rmmissing(DataEr2(:,2)-DataEr2(:,4))))
mean(abs(rmmissing(DataEr3(:,1)-DataEr3(:,4))))
mean(abs(rmmissing(DataEr3(:,2)-DataEr3(:,5))))
mean(abs(rmmissing(DataEr3(:,3)-DataEr3(:,6))))
mean(abs(rmmissing(DataEr4(:,1)-DataEr4(:,5))))
mean(abs(rmmissing(DataEr4(:,2)-DataEr4(:,6))))
mean(abs(rmmissing(DataEr4(:,3)-DataEr4(:,7))))
mean(abs(rmmissing(DataEr4(:,4)-DataEr4(:,8))))